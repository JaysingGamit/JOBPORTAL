-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2015 at 05:32 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `a_id` int(25) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE IF NOT EXISTS `employer` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(25) NOT NULL,
  `l_name` varchar(25) NOT NULL,
  `u_name` varchar(25) NOT NULL,
  `pass` varchar(25) NOT NULL,
  `btype` varchar(25) NOT NULL,
  `b_name` varchar(25) NOT NULL,
  `e_id` varchar(25) NOT NULL,
  `m_no` varchar(25) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`eid`, `f_name`, `l_name`, `u_name`, `pass`, `btype`, `b_name`, `e_id`, `m_no`, `gender`, `status`) VALUES
(17, 'khushbu', 'mistry', 'khushbu', '456', 'Goverment Institution', 'casps', 'khushb@gamil.com', '8347803417', 'female', '0'),
(18, 'reyu', 'patel', 'r', 'p', 'Individual', 'hvh', 'rey@yahoo.com', '4567891230', 'male', '1'),
(20, 'krupa', 'patel', 'k', 'p', 'Private Organization', 'fyg', 'kgp@yahoo.com', '7894561230', 'female', '0');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `f_id` int(11) NOT NULL AUTO_INCREMENT,
  `na` varchar(25) NOT NULL,
  `em` varchar(25) NOT NULL,
  `m_no` varchar(25) NOT NULL,
  `ms` varchar(25) NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_id`, `na`, `em`, `m_no`, `ms`) VALUES
(2, 'khushbu', '', '', 'hiii'),
(3, 'khushbu', '', '', 'hiii');

-- --------------------------------------------------------

--
-- Table structure for table `jobpost`
--

CREATE TABLE IF NOT EXISTS `jobpost` (
  `jpid` int(11) NOT NULL AUTO_INCREMENT,
  `jl_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `company_name` varchar(55) NOT NULL,
  `j_ti` varchar(25) NOT NULL,
  `p_by` varchar(25) NOT NULL,
  `j_ob` varchar(500) NOT NULL,
  `sal` varchar(25) NOT NULL,
  `co_no` varchar(25) NOT NULL,
  `e_mail` varchar(25) NOT NULL,
  `location` varchar(25) NOT NULL,
  `da` date NOT NULL,
  `mo` varchar(25) NOT NULL,
  `ye` varchar(25) NOT NULL,
  `j_type` varchar(25) NOT NULL,
  PRIMARY KEY (`jpid`),
  KEY `jl_id` (`jl_id`),
  KEY `id` (`id`),
  KEY `jl_id_2` (`jl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `jobpost`
--

INSERT INTO `jobpost` (`jpid`, `jl_id`, `id`, `company_name`, `j_ti`, `p_by`, `j_ob`, `sal`, `co_no`, `e_mail`, `location`, `da`, `mo`, `ye`, `j_type`) VALUES
(99, 1, 1, 'CASPS', 'Accountant', 'Krupa', 'purchase order', '5000', '7894561230', 'Krupap@yahoo.com', 'Gujarat', '2015-02-05', 'Nov', '2010', 'Part Time'),
(100, 2, 2, 'BPCO', 'PHP devloper', 'khushbu', 'programmer', '50000', '7894561230', 'khushbu@yahoo.com', 'Maharastra', '2015-04-15', '5', '2012', 'full time'),
(101, 3, 3, 'SAMSUNG', 'JAVA', 'REY', 'programming', '100000', '0123456987', 'rey@yahoo.com', 'Delhi', '2015-04-22', '4', '2015', 'full/part time'),
(102, 4, 4, 'CASPS', 'lecture', 'Avni', 'programmer', '5000', '4561230789', 'av@gmail.com', 'Noida', '2015-04-30', '4', '2015', 'full time');

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker`
--

CREATE TABLE IF NOT EXISTS `jobseeker` (
  `j_id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `address` varchar(250) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `languagesknown` varchar(50) NOT NULL,
  `date` varchar(25) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `maritalstatus` varchar(20) NOT NULL,
  `co_id` varchar(25) NOT NULL,
  `s_id` varchar(25) NOT NULL,
  `c_id` varchar(25) NOT NULL,
  `phoneno` varchar(25) NOT NULL,
  `compro` varchar(50) NOT NULL,
  `language` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`j_id`),
  KEY `co_id` (`co_id`),
  KEY `s_id` (`s_id`),
  KEY `c_id` (`c_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT AUTO_INCREMENT=130 ;

--
-- Dumping data for table `jobseeker`
--

INSERT INTO `jobseeker` (`j_id`, `uname`, `password`, `address`, `emailid`, `languagesknown`, `date`, `gender`, `maritalstatus`, `co_id`, `s_id`, `c_id`, `phoneno`, `compro`, `language`, `status`) VALUES
(128, 'krina', '11', 'jg', 'krinamistry05@gmail.com', '', '2/12/2013', 'Female', 'married', 'eqr', 'reqr', 'eqrqer', '333434', 'Basic operations', 'Malayalam', '1'),
(129, 'a', 'a', '212,Hormezed bag\r\nGoharbag', 'krinamistry05@gmail.com', 'gujarati', '2/12/2013', 'Female', 'married', 'eqr', 'India', 'Bilimora', '07802030713', '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `job_desg`
--

CREATE TABLE IF NOT EXISTS `job_desg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desg_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `job_desg`
--

INSERT INTO `job_desg` (`id`, `desg_name`) VALUES
(1, 'Accountant'),
(2, 'Php Developer'),
(3, 'Asp.net'),
(4, 'Lecturer');

-- --------------------------------------------------------

--
-- Table structure for table `job_location`
--

CREATE TABLE IF NOT EXISTS `job_location` (
  `jl_id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(66) NOT NULL,
  PRIMARY KEY (`jl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `job_location`
--

INSERT INTO `job_location` (`jl_id`, `location`) VALUES
(1, 'Gujarat'),
(2, 'Maharastra'),
(3, 'Delhi'),
(4, 'Noida');

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE IF NOT EXISTS `resume` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(25) NOT NULL,
  `uname` varchar(25) NOT NULL,
  `nationality` varchar(25) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `c_country` varchar(25) NOT NULL,
  `c_city` varchar(25) NOT NULL,
  `c_no` varchar(25) NOT NULL,
  `degree` varchar(25) NOT NULL,
  `institution` varchar(25) NOT NULL,
  `mdegree` varchar(25) NOT NULL,
  `minstitution` varchar(25) NOT NULL,
  `yog` varchar(25) NOT NULL,
  `t_experience` varchar(25) NOT NULL,
  `a_salary` varchar(25) NOT NULL,
  `industry` varchar(25) NOT NULL,
  `f_area` varchar(25) NOT NULL,
  `r_heading` varchar(25) NOT NULL,
  `resume` varchar(76) NOT NULL,
  `j_id` int(11) NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `uname` (`uname`),
  KEY `j_id` (`j_id`),
  KEY `j_id_2` (`j_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `resume`
--

INSERT INTO `resume` (`rid`, `email`, `uname`, `nationality`, `dob`, `gender`, `c_country`, `c_city`, `c_no`, `degree`, `institution`, `mdegree`, `minstitution`, `yog`, `t_experience`, `a_salary`, `industry`, `f_area`, `r_heading`, `resume`, `j_id`) VALUES
(2, 'kp@yahoo.com', 'kp', 'India', '2/2/2010', 'female', 'India', 'Navsari', '7894561230', 'B.Com', 'fghvggj', 'M.com', 'ssss', '1999', '', 'Yearly', 'Automobile,  Manufacturin', 'Advertising/Event Managem', 'res', 'Resume/', 0),
(3, 'krupap74@yahoo.com', 'krupa', 'India', '2/2/2010', 'female', 'India', 'Navsari', '7894561230', 'Bca', 'fghvggj', ' M.Sc (Computer Science)', 'ssss', '2005', '', 'Yearly', 'Food & Beverages', 'Import/Export', 'hj', 'Resume/Array', 130);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
