<?php
	error_reporting(0);
	ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['eid']; 
    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname']; 


   $s="select * from employer where u_name='$uname'";
    $r1=mysql_query($s);

  
     /*$uname=$_SESSION['uname'];*/  
  
 

    if(isset($_REQUEST['e_id']))
    {
        $id=$_REQUEST['e_id'];

        $del="delete from empprofile where eid='$id'";
        mysql_query($del);
        header("location:employerpro.php");
    }  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>employerpro</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
            <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employer</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
?>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <!--<span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />-->
        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
       <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   
      <!--  <h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-style:inherit;color:#00F";>Career.Com</span> <small>Company Slogan Here</small></a></h1>
      --></div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider">
         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a>
                       
         </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <!--<h2><span>Excellent Solution</span> For Your Business</h2>-->
          <!--<p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>
-->          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="640" height="188" alt="" class="fl" /></div>
          <div class="post_content">
            <p>
              <fieldset class="div_midal">
        <div>
            <p>&nbsp;&nbsp;<font size="6" face="Times New Roman, Times, serif" color="#2695C3" style="margin-left:20px;" ><h1>Welcome <?php echo $uname?></h1></font></p>
            <br>
           <table style="margin-left:280;" border="3" cellpadding="3" cellspacing="5" width="400px"  >

                                <?php           
                                    while($row=mysql_fetch_array($r1))   
                                    {
                                    ?>           


                                    <tr>
                                        <th>Id</th> 
                                        <td><?php echo $row[0]?></td>
                                    </tr>

                                    <tr>                     
                                        <th>First Name</th> 
                                        <td><?php echo $row[1]?></td>  
                                    </tr>
                                    <tr>                     
                                        <th>Last Name</th> 
                                        <td><?php echo $row[2]?></td>  
                                    </tr>
                                    <tr>                     
                                        <th>User Name</th> 
                                        <td><?php echo $row[3]?></td>  
                                    </tr>
                                    <tr>                     
                                        <th> Password</th> 
                                        <td><?php echo $row[4]?></td>  
                                    </tr>
                                    <tr>                     
                                        <th>Business Type</th> 
                                        <td><?php echo $row[5]?></td>  
                                    </tr>
                                    <tr>                     
                                        <th>Business Name</th> 
                                        <td><?php echo $row[6]?></td>  
                                    </tr>
                                    <tr>                     
                                        <th>Email Id </th> 
                                        <td><?php echo $row[7]?></td>  
                                    </tr>
                                    <tr>                     
                                        <th>Mobile NO</th> 
                                        <td><?php echo $row[8]?></td>  
                                    </tr>
                                    <tr>                     
                                        <th>Gender</th> 
                                        <td><?php echo $row[9]?></td>  
                                    </tr>

                                    <tr>
                                        <td>

                                        </td>
                                        <td>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="employerpro.php?e_id=<?php echo $row['eid']?>"><input type="button" name="delete" value="Delete" </a>
                                        </td>

                                    </tr>
                                    </tr>
                                    <?php
                                    }

                                ?>


                            </table>
                            <br></br>
                </div>
                 </fieldset>

            </p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
                   <li><a href="Main Page.php">Main Page</a>
                                <li><a href="empreg.php?eid=<?php echo $r['eid']?>">Edit Profile</a></li>
                                <li><a href="employerpro.php?eid=<?php echo $r['eid']?>">View Profile</a></li>
                                <li><a href=" employerchang pass.php?eid=<?php echo $r['eid']?>">Change Password</li>
                                <li><a href="sresume.php">Search Resume</li> 
                           

                        <li><a href="Job post.php">Post Job</li> 
                          
                        <li><a href="feed back.php">Feedback</li> 
                        <li class="last"><a href="index.php">Logout</a> </li> 
          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
