<?php                    
    error_reporting(0);                                                                   
    ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['eid'];
    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname']; 

    $s="select * from employer where u_name='$uname'";
    $r1=mysql_query($s);
    $r=mysql_fetch_array($r1);


    /*$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname'];       
    */
    /*$sel="select * from employer ";
    $res=mysql_query($sel);
    $rows=mysql_fetch_array($res);
    */

    if(isset($_REQUEST['update'])) 
    {
        $password=$_REQUEST['pass'];
        if($r['pass']==$_REQUEST['currentpassword'])
        {
            $password=$_REQUEST['newpassword'];

            $up="update employer set pass='$password' where u_name='$uname'";
            mysql_query($up);

            echo "Your Password Successfully Changing";
        }
        else
        {
            echo "Invalid current Password";
        }

    }                   
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>employerchang pass</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
           <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employee</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
?>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
      <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
        <!--<h1><a href="index.html">Career<span>.Com</span> <small>Company Slogan Here</small></a></h1>-->
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> 
        <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a>

        <!--<a href="#"><img src="images/slide1.jpg" width="918" height="310" alt="" /> </a>
         <a href="#"><img src="images/slide2.jpg" width="918" height="310" alt="" /> </a> 
         <a href="#"><img src="images/slide3.jpg" width="918" height="310" alt="" /> </a>--> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <!--<h2><span>Excellent Solution</span> For Your Business</h2>
          <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>
-->          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="640" height="188" alt="" class="fl" /></div>
          <div class="post_content">
            <p>  <form class="div_midal" action="" method="post" name="regs" onSubmit="return changepassword();">                   

                    <br>
                    <p>&nbsp;&nbsp;<font size="6" face="Times New Roman, Times, serif" color="#2695C3" style="margin-left:20px;" >
                            <h1 align="left">Welcome <?php echo $uname?></h1>
                        </font>
                    </p>

                    <br>

                    <table width="350" height="255" border="0" cellspacing="0" cellpadding="2" 
                        style="BORDER-RIGHT:#2695C3 1px solid; BORDER-TOP: #2695C3 1px solid; BORDER-LEFT: #2695C3 1px solid; border-bottom: #2695C3 1px solid; float: left; margin-left:40px;border-radius:7px;">
                        <tr>
                            <td colspan="10" align="center" bgcolor="#2695C3" style="border-bottom: #2695C3 1px solid;border-radius:7px;"><span style="font-weight:bold;font-size:15px; color: black ;">Change Password</span></td>
                        </tr>     
                        <tr>
                            <td style=" padding-left: 15px;" id="labels">Cureent Password:</td>
                        </tr>
                        <tr>
                            <td style="padding-left: 15px;"><input type="password" name="currentpassword" class="textboxes"></td>
                        </tr>
                        <tr>
                            <td style="padding-left: 15px;" id="labels">New Password:</td>
                        </tr>
                        <tr>
                            <td style="padding-left: 15px;" ><input type="password" name="newpassword" class="textboxes"></td>
                        </tr>
                        <tr>
                            <td><p id="newpassword" style="color: red;font-size: 12pt;font-weight: 900;"></p></td>
                        </tr>
                        <tr>
                            <td style="padding-left: 15px;" id="labels">Confirm New Password:</td>
                        </tr>
                        <tr>
                            <td style="padding-left: 15px;"><input type="password" name="confirmpassword" class="textboxes"></td>
                        </tr>
                        <tr>
                            <td><p id="newpassword" style="color: red;font-size: 12pt;font-weight: 900;"></p></td>
                        </tr>

                        <tr>    
                            <td style="padding-left: 15px;"><input type="submit" name="update" value="Save Change" style="width:120px; height:30px;"></td>
                        </tr>
                    </table>

                </form> </p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
             <li><a href="Main Page.php">Main Page</a>
                                <li><a href="empreg.php?eid=<?php echo $r['eid']?>">Edit Profile</a></li>
                                <li><a href="employerpro.php?eid=<?php echo $r['eid']?>">View Profile</a></li>
                                <li><a href=" employerchang pass.php?eid=<?php echo $r['eid']?>">Change Password</a></li>
                                <li><a href="sresume.php?eid=<?php echo $r['eid']?>">Search Resume</a></li> 
                           

                        <li><a href="Job post.php?eid=<?php echo $r['eid']?>">Post Job</a></li> 
                              
                        <li><a href="feed back.php?eid=<?php echo $r['eid']?>">Feedback</a></li> 
                        <li class="last"><a href="index.php">Logout</a> </li> 

          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>



































