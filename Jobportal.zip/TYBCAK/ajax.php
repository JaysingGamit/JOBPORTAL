<?php $db= new mysqli('localhost','root','','job_portal'); 
extract($_POST);
$user_id=$db->real_escape_string($id);
$status=$db->real_escape_string($status);
$sql=$db->query("UPDATE jobseeker SET status='$status' WHERE j_id='$id'");
echo 1;
?>
