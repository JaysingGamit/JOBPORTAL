<?php                    
    error_reporting(0); 
	ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['j_id'];
    //$uname=$_REQUEST['uname'];
       $uname=$_SESSION['uname']; 
    $s="select * from j_msg where uname='$uname'";
       $r1=mysql_query($s); 
         
    

 if(isset($_REQUEST['j_id']))
    {
        $id=$_REQUEST['j_id'];

        $del="delete from jobseeker where j_id='$id'";
        mysql_query($del);
        header("location:Job Seeker.php");
    }  


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>jmsg</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
            <script type="text/javascript">
            function mesg(form)
            {     

                ;
                var i=document.getElementById('i');     
                var j=document.getElementById('j');       
                var k=document.getElementById('k');
                var l=document.getElementById('l');
                var m=document.getElementById('m');     
                var n=document.getElementById('n');       
                var o=document.getElementById('o');
                var p=document.getElementById('p');
                
                var em = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                var alpha = /^[a-zA-Z' _]+$/; 
                  var tel_no=/^[\d]{6,10}$/;
                if(i.value=='')
                    {

                    alert("Please fill the Name");
                    i.focus();
                    return false;

                }
                else if(!alpha.test(i.value))
                    {
                    alert("Please enter charecter value");
                    i.value= '';
                    i.focus();
                    return false;

                }
              
              
               else if(j.value=='')
            {

                    alert("Please fill the Address ");
                    j.focus();
                    return false;

                }
                
               
               
               else if(k.value=='')
            {

                    alert("Please fill the Bechlol Degree");
                    k.focus();
                    return false;

                }
                else if(!alpha.test(k.value))
                    {
                    alert("Please enter charecter value");
                    k.value= '';
                    k.focus();
                    return false;

                }
               
                else if(l.value=='')
            {

                    alert("Please fill the Master Degree");
                    l.focus();
                    return false;

                }
                else if(!alpha.test(l.value))
                    {
                    alert("Please enter charecter value");
                    l.value= '';
                    l.focus();
                    return false;

                }
                

                else if(m.value=='')
                    {

                    alert("Please fill the Email");
                    m.focus();
                    return false;

                }
                else if(!em.test(m.value))
                    {
                    alert("Please Enter Valid Email Id ");
                    m.value= '';
                    m.focus();
                    return false;

                }
                
               
                  if(n.value=='')
                {

                alert("Please fill the Mobile No");
                n.focus();
                return false;

            }
           else if(!tel_no.test(n.value))
                {
                alert("Invalid Mobile Numbe...");
                return false;
            }   

                
                   else if(o.value=='')
                    {

                    alert("Please fill the resume Heading");
                    o.focus();
                    return false;
                    }

                if(p.value=='')
                    {

                    alert("Please Select Resume ");
                    p.focus();
                    return false;

                    }

                else
                    {
                return true;
                    }
            }                     

        </script> 

</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
           <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employee</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
?>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
        <h1><a href="index.html">Career<span>.Com</span> <small>Company Slogan Here</small></a></h1>
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="918" height="310" alt="" /> </a> <a href="#"><img src="images/slide2.jpg" width="918" height="310" alt="" /> </a> <a href="#"><img src="images/slide3.jpg" width="918" height="310" alt="" /> </a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Excellent Solution</span> For Your Business</h2>
          <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>
          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="640" height="188" alt="" class="fl" /></div>
          <div class="post_content">
            <p>  <form name="good" method="post">  
                <p>&nbsp;&nbsp;<font size="6" face="Times New Roman, Times, serif" color="#2695C3" style="margin-left:20px;" ><h1>Welcome <?php echo $uname?></h1></font></p>
                <table style="margin-left:200 ;" width="564" border="3" cellpadding="3" cellspacing="5"> 

                    <?php
                        while($row=mysql_fetch_array($r1))
                        {
                        ?>
                        <tr>
                            <th>Name:</th> 
                            <td><?php echo $row[2]?></td>
                        </tr>
                        <tr>                     
                            <th>Address:</th> 
                            <td><?php echo $row[3]?></td>  
                        </tr>
                        <tr>
                            <th>Bechlor Degree:</th> 
                            <td><?php echo $row[4]?></td>
                        </tr>
                        <tr>                     
                            <th>Master Degree:</th> 
                            <td><?php echo $row[5]?></td>  
                        </tr>
                        

                        <tr>                     
                            <th>Email Id</th> 
                            <td><?php echo $row[6]?></td>  
                        </tr>
                        <tr>                     
                            <th>Mobile</th> 
                            <td><?php echo $row[7]?></td>  
                        </tr>
                        <tr>
                            <th>Resume Hedline:</th> 
                            <td><?php echo $row[8]?></td>
                        </tr>
                        <tr>                     
                            <th>Resume:</th> 
                            <td><?php echo $row[9]?></td>  
                        </tr>


                        </td>
                        </tr>
                        </tr>
                        <?php 
                        }
                    ?>

                </table>
            </form>  </p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
             <li><a href="Main Page.php">Main Page</a>
                                <li><a href="empreg.php?eid=<?php echo $r['eid']?>">Edit Profile</a></li>
                                <li><a href="employerpro.php?eid=<?php echo $r['eid']?>">View Profile</a></li>
                                <li><a href=" employerchang pass.php?eid=<?php echo $r['eid']?>">Change Password</li>
                                <li><a href="sresume.php">Search Resume</li> 
                           

                        <li><a href="Job post.php">Post Job</li> 
                           
                        <li><a href="feed back.php">Feedback</li> 
                        <li class="last"><a href="index.php">Logout</a> </li> 

          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>
