<?php                 
   error_reporting(0);
    ob_start();
    session_start();        
    include('conn.php');     
    $id=$_SESSION['rid'];
    // $uname=$_REQUEST['uname'];

    $uname= $_SESSION['uname'];

    if(isset($_REQUEST['send']))
    {
         $o=$_REQUEST['o'];
        $n=$_REQUEST['n'];
        $a=$_REQUEST['a'];
        $b=$_REQUEST['b'];
        $m=$_REQUEST['m'];
        $e=$_REQUEST['e'];
        $mo=$_REQUEST['mo'];
       $r=$_REQUEST['r'];
        $u=$_REQUEST['u'];
        
        

        $i="insert into j_msg (uname,name,address,b_degree,m_degree,email,mobile,r_hedline,u_resume)values('$o','$n','$a','$b','$m','$e','$mo','$r','$u')";
       mysql_query($i);
    }  
    $s="select * from resume where uname='$uname'";     
$re=mysql_query($s);
$b=mysql_fetch_array($re);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>jobmesg</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
 <script type="text/javascript">
        function show(str)
        {
            //alert("dsjfghdsfhdsghfdgs");
            if(str.length>0)
                {
                var a;
                if(window.XMLHttpRequest)
                    {
                    a = new XMLHttpRequest();
                }
                a.open("GET","my.php?h="+str,true);
                a.send();
                a.onreadystatechange=function()
                {
                    if(a.readyState==4)
                        {
                        document.getElementById('e').innerHTML=a.responseText;
                    }
                }  
            }
            else
                {
                document.getElementById('e').innerHTML="Searching Result";
            }
        }



    </script>

          <script type="text/javascript">
            function mesg(form)
            {     

                ;
                var i=document.getElementById('i');     
                var j=document.getElementById('j');       
                var k=document.getElementById('k');
                var l=document.getElementById('l');
                var m=document.getElementById('m');     
                var n=document.getElementById('n');       
                var o=document.getElementById('o');
                var p=document.getElementById('p');
                
                var em = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                var alpha = /^[a-zA-Z' _]+$/; 
                  var tel_no=/^[\d]{6,10}$/;
                if(i.value=='')
                    {

                    alert("Please fill the Name");
                    i.focus();
                    return false;

                }
                else if(!alpha.test(i.value))
                    {
                    alert("Please enter charecter value");
                    i.value= '';
                    i.focus();
                    return false;

                }
              
              
               else if(j.value=='')
            {

                    alert("Please fill the Address ");
                    j.focus();
                    return false;

                }
                
               
               
               else if(k.value=='')
            {

                    alert("Please fill the Bechlol Degree");
                    k.focus();
                    return false;

                }
                else if(!alpha.test(k.value))
                    {
                    alert("Please enter charecter value");
                    k.value= '';
                    k.focus();
                    return false;

                }
               
                else if(l.value=='')
            {

                    alert("Please fill the Master Degree");
                    l.focus();
                    return false;

                }
                else if(!alpha.test(l.value))
                    {
                    alert("Please enter charecter value");
                    l.value= '';
                    l.focus();
                    return false;

                }
                

                else if(m.value=='')
                    {

                    alert("Please fill the Email");
                    m.focus();
                    return false;

                }
                else if(!em.test(m.value))
                    {
                    alert("Please Enter Valid Email Id ");
                    m.value= '';
                    m.focus();
                    return false;

                }
                
               
                  if(n.value=='')
                {

                alert("Please fill the Mobile No");
                n.focus();
                return false;

            }
           else if(!tel_no.test(n.value))
                {
                alert("Invalid Mobile Numbe...");
                return false;
            }   

                
                   else if(o.value=='')
                    {

                    alert("Please fill the resume Heading");
                    o.focus();
                    return false;
                    }

                if(p.value=='')
                    {

                    alert("Please Select Resume ");
                    p.focus();
                    return false;

                    }

                else
                    {
                return true;
                    }
            }                     

        </script> 
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
            <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employer</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
?>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
         <!-- <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
-->        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
       <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   
        <!--<h1><a href="index.html">Career<span>.Com</span> <small>Company Slogan Here</small></a></h1>
     --> </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="918" height="310" alt="" /> </a> <a href="#"><img src="images/slide2.jpg" width="918" height="310" alt="" /> </a> <a href="#"><img src="images/slide3.jpg" width="918" height="310" alt="" /> </a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Excellent Solution</span> For Your Business</h2>
          <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>
          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="640" height="188" alt="" class="fl" /></div>
          <div class="post_content">
            <p>
                                           <fieldset class="div_midal">
                      <form name="good" method="post">  
                   
                    <p><font size="6" face="Times New Roman, Times, serif" color="#2695C3" style="margin-left:20px;" ><h1>Welcome <?php echo $uname?></h1></font></p>

                    <table style="margin-left:20px;" width="444" border="3" cellpadding="3" cellspacing="5"> 

                                                           <tr>
                     <td>Uname:</td>
                        <td width="66%"><input type="text" name="o" value="<?php echo $b['uname']?>"  id="a" class="text" style="width:300px;"></td>
                    </tr>
                     <td>Name:</td>
                        <td width="66%"><input type="text" name="n" value="<?php echo $r1[1]?>"  id="i" class="text" style="width:300px;"></td>
                    </tr>
                    <tr>
                        <td>Address:</td>
                        <td><textarea rows="3" cols="35" name="a" value="<?php echo $r1[2]?>" id="j"></textarea></td>
                    </tr>
                    <tr>
                        <td>Bechlor Degree:</td>
                        <td width="66%"><input type="text" name="b" value="<?php echo $r1[3]?>"  id="k" class="text" style="width:300px;"></td>
                    </tr>
                     <tr>
                        <td>Master Degree:</td>
                        <td width="66%"><input type="text" name="m" value="<?php echo $r1[4]?>"  id="l" class="text" style="width:300px;"></td>
                    </tr>
                    <tr>
                        <td>Email Id:</td>
                        <td width="66%"><input type="text" name="e" value="<?php echo $r1[5]?>"  id="m" class="text" style="width:300px;"></td>
                    </tr>
                      <tr>
                        <td>Mobile No:</td>
                        <td width="66%"><input type="text" name="mo" value="<?php echo $r1[6]?>"  id="n" class="text" style="width:300px;"></td>
                    </tr>

                        <tr>
                            <td>Resume Headline: </td>
                            <td width="66%" align="left"><input type="text" name="r" id="o" value="<?php echo $r1[7]?>" style="width:300px;"></td>
                        </tr>
                        <tr>
                            <td> Upload resume: </td>
                            <td><input name="u" value="<?php echo $r1[8]?>" id="p" type="file" class="multi" accept="doc|rtf|txt|pdf" validate="required:true" style="width:300px;">
                                <br>
                                <span class="grey-11">Please make sure your document is closed before uploading it to avoid any errors.
                                    - You may upload Word / Acrobat / Text (<strong>.doc / .pdf / .txt</strong>) documents.
                                    - Maximum size 125kb</span></td>
                        </tr>

                        <tr>                                     </tr>

                    
                    
                    <tr>
                        <td></td>
                        <td align="center">
                        <input type="submit" name="send" value="Apply Now..."onClick="return mesg(this.form);"/>   
                        <td>
                    </tr>
                    </table>
                </form> 
        </fieldset>
            </p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
                    <li><a href="Home.php">Main Page</a></li>
                    <li><a href="jobseeker_home.php?uname=<?php echo $uname?>">Account Detail</a></li>
                    <li><a href="jseeker_pass_change.php">Change Password </a></li>
                    <li><a href="Post Resume.php">Resume</a></li>
                    <li><a href="eresume.php">Show Resume</li>
                    <li><a href="search job1.php">Job Search</a></li>
                    <li><a href="feed back1.php">Feed Back </a></li>
                    <li><a href="Contect.php">Contact Us</a></li>
                    
                    <li class="last"><a href="logout.php">Logout</a></li> 
          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>
