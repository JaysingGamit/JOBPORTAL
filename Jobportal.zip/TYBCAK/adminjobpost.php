<?php 
	error_reporting(0);
	ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['j_id'];
        $id=$_REQUEST['jpid'];

    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['username'];                         
 if(isset($_REQUEST['save']))
    {
        //echo "hello";
        // $emp_id=$_REQUEST[''];
		$companyname=$_REQUEST['company_name'];  
        $jobtitle=$_REQUEST['job'];
        $postby=$_REQUEST['pb'];
      //  $jobfunction=$_REQUEST['jf'];
        $jobdescriptation=$_REQUEST['jo'];
        //$da=$_REQUEST['d'];
        //$mont=$_REQUEST['m']; 
        //$yea=$_REQUEST['y']; 
        $salary=$_REQUEST['sl'];
        $contactno=$_REQUEST['cn'];
        $email=$_REQUEST['em'];
        $location=$_REQUEST['lo'];  
        $day=$_REQUEST['day'];
        //$month=$_REQUEST['month'];
        //$year=$_REQUEST['year']; 
         $jobtype=$_REQUEST['jt'];
         $basic=$_REQUEST['basic'];
		   $master=$_REQUEST['master'];
		     $skill=$_REQUEST['skill']; 
				$e=$_REQUEST['e'];
        echo $sql="insert into jobpost(company_name,j_ti,p_by,j_ob,sal,co_no,e_mail,location,da,j_type ,basic,master,skill,e)       values('$companyname','$jobtitle','$postby','$jobdecriptation','$salary','$contactno','$email','$location','$day','$jobtype','$basic','$master','$skill','$e')";

        $t=mysql_query($sql) or die(mysql_error());

        echo "data insert";
        header('location:adminhome.php');
    }
        if(isset($_REQUEST['jpid']))
    {
        $id=$_REQUEST['jpid'];
        $s="select * from jobpost where jpid='$id'";     
        $s=mysql_query($s);
        $r1=mysql_fetch_array($s);
    }
    if(isset($_REQUEST['update']))
    {
        $id=$_REQUEST['jpid'];
		$companyname=$_REQUEST['company_name'];
        $jobtitle=$_REQUEST['job'];
        $postby=$_REQUEST['pb'];
       // $jobfunction=$_REQUEST['jf'];
        $jobdiscriptation=$_REQUEST['jo'];
        //$da=$_REQUEST['d'];
        //$mont=$_REQUEST['m']; 
        //$yea=$_REQUEST['y']; 
        $salary=$_REQUEST['sl'];
        $contactno=$_REQUEST['cn'];
        $email=$_REQUEST['em'];
        $location=$_REQUEST['lo'];  
        $day=$_REQUEST['day'];
        //$month=$_REQUEST['month'];
        //$year=$_REQUEST['year']; 
        $jobtype=$_REQUEST['jt']; 
		$basic=$_REQUEST['basic'];
		   $master=$_REQUEST['master'];
		     $skill=$_REQUEST['skill']; 
				$e=$_REQUEST['e'];
        

        $u="update jobpost set company_name='$companyname', j_ti='$jobtitle',p_by='$postby',j_ob='$jobdiscriptation',sal='$salary',co_no='$contactno',e_mail='$email',location='$location',da='$day',j_type='$jobtype' ,basic='$basic',master='$master',skill='$skill'where jpid='$id'";
        mysql_query($u);
        header("location:adminviewjob.php");
        }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>adminjobpost</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
 <script type="text/javascript">

            function mesg(form)
            {     
				var companyname=document.getElementById('company_name');
                var jobtitle=document.getElementById('job');
                var postby=document.getElementById('pb');     
                var jobfuction=document.getElementById('jf');     
                var jobdescriptation=document.getElementById('ad');         
                var d=document.getElementById('a');
                var m=document.getElementById('b');
                var y=document.getElementById('c');
                var sa=document.getElementById('sa');
                
                var contact=document.getElementById('cno');

                var email=document.getElementById('mail');
                var day=document.getElementById('d');
                var month=document.getElementById('m');
                var year=document.getElementById('y');      
                var jobtype=document.getElementById('jot');
                                

                   
                 var pa = /^[0-9'_{10}]+$/; 
                var alpha = /^[a-zA-Z' _]+$/;
                 var pho = /^\[10]+$/; 
                 var em = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/; 
               
			    if(companyname.value == '')
                    {
                    alert("Please fill up the companyname");
                    company_name.focus();
                    return false;
                } 
                    else if(!alpha.test(companyname.value))
                    {

                    alert("Please enter companyname is Charcter values");
                    company_name.focus();
                    companyname.value='';
                    return false;
                } 

			   
			   
			   
			   
                if(job.value == '')
                    {
                    alert("Please fill up the Job Title");
                    job.focus();
                    return false;
                } 
                    else if(!alpha.test(job.value))
                    {

                    alert("Please enter Job Title is Charcter values");
                    job.focus();
                    job.value='';
                    return false;
                } 

                 
                  if(pb.value == '')
                    {
                    alert("Please fill up the Post By");
                    pb.focus();
                    return false;
                } 
                   else if(!alpha.test(pb.value))
                    {

                    alert("Please enter Post Job is Charcter values");
                   pb.focus();
                    pb.value='';
                    return false;
                } 

                 
                  if(jf.value == '')
                    {
                    alert("Please fill up the Job Function");
                    jf.focus();
                    return false;
                } 
                  else if(!alpha.test(jf.value))
                    {

                    alert("Please enter Job Function is Charcter values");
                    jf.focus();
                    jf.value='';
                    return false;
                } 
               
               if(ad.value == '')
                    {
                    alert("Please fill up the Job Descriptation");
                    ad.focus();
                    return false;
                } 
                    else if(!alpha.test(ad.value))
                    {

                    alert("Please enter Job Descriptation in Charecter");
                    ad.focus();
                    ad.value='';
                    return false;
                } 

                 
                 

                  
                   else if(sa.value=='')
                    {
                    alert("plese fill up the salary");
                    sa.focus();
                    return false;
                }
                else if(!pa.test(sa.value))
                    {

                    alert("please enter numeric values");
                    sa.focus();
                    sa.value='';
                    return false;
                }
               

               
               
               
               else if(cno.value=='')
                    {

                    alert("Please fill the contecno");
                    cno.focus();
                    return false;

                }
                else if(!pho.test(phoneno.value))
                    {
                    alert("invalid contec number");
                    cno.value= '';
                    cno.focus();
                    return false;

                }  
                 
                 
                  else if(mail.value=='')
                    {

                    alert("Please fill the email");
                    mail.focus();
                    return false;

                }
                else if(!em.test(mail.value))
                    {
                    alert("Please enter valid Emailid");
                    mail.value= '';
                    mail.focus();
                    return false;

                }
                
                           
                else
                    {
                    return false;
                }
                return true;

            }                     

        </script> 
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
           <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employer</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
?>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
         <!-- <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />-->
        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
       <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   
        <!--<h1 style="font-size:40px;color:#00C;" ><a href="index.html"><span style="font-style:inherit;color:#00F">Career.Com</span> <small>Company Slogan Here</small></a></h1>
     --> </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider">
         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a></div>
                       
         </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="">
          <!--<h2><span>Excellent Solution</span> For Your Business</h2>
          <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>
-->          <div class="clr"></div>
          <div class="post_content">
            <!--<marquee behavior="alternate"><h3 style="font-size:24px;color:red;"> Add Job Information</h3></marquee>
            -->
            <p>          <form name="" method="post" style="margin-top:-100px">         
                      <br>                      
                      <p><font size="6" face="Times New Roman, Times, serif" color="#2695C3"><h1>&nbsp;&nbsp;Post a new job  here</h1></font></p> 
                     <br>
                    <table width="617" height="427" border="3" cellpadding="3" cellspacing="5"  style="margin-left:;">
                    			<tr>
                        <td>Companyname:</td>
                            <td width="66%"><input type="text" name="Companyname" value="<?php echo $r1[1]?>"  id="Company_name" class="text" style="width:300px;"></td>
                        </tr>

                    
                    
                    
                        <tr>
                            <td >Job Title:</td>
                            <td><input name="job" value="<?php echo $r1[2]?>" class="text" id="job" style="width:300px;" type="text" ></td>
                        </tr>
			



                        <tr>
                            <td>Post By:</td>
                            <td width="66%"><input type="text" name="pb" value="<?php echo $r1[3]?>"  id="pb" class="text" style="width:300px;"></td>
                        </tr>

                        <tr>
                            <td>Job Function: </td>
                            <td>
                            <input type="text" name="jf" value="<?php echo $r1[4]?>"  id="jf" class="text" style="width:300px;">
                            </td>
                        </tr>
                            <tr>
                            <td>Job Descriptation:</td>
                            <td><textarea rows="3" cols="35" name="jo"value="<?php echo $r1[5]?>" id="ad"></textarea></td>
                        </tr>
                        
                             <tr>
                    <td>Start date:</td>
                    <td>
                        <select name="d">
                            <option value="<?php echo $r1[6]?>" id="a" selected="selected">Da</option>
                            <?php
                                for($i=1;$i<=31;$i++)
                                {
                                    if($row['d']== $i)
                                    {
                                    ?>
                                    <option value="<?php echo $i?>" selected="selected"><?php echo $i?></option>
                                    <?php
                                    }
                                    else
                                    {
                                    ?>
                                    <option value="<?php echo $i?>"><?php echo $i?></option>
                                    <?php
                                    }
                                }
                            ?>
                        </select>




                        <select name="m">
                            <option value="<?php echo $r1[7]?>" id="b" selected="">Month:</option>
                            <?php
                                if($row['m']=="Jan")
                                {

                                ?>
                                <option value="Jan" selected="selected">Jan</option>  
                                <?php
                                }
                                else
                                {
                                ?>                              
                                <option value="Jan">Jan</option> 
                                <?php
                                }
                            ?>
                            <?php
                                if($row['m']=="Feb")
                                {

                                ?>
                                <option value="Feb" selected="selected">Feb</option>  
                                <?php
                                }
                                else
                                {
                                ?>                              
                                <option value="Feb">Feb</option> 
                                <?php
                                }
                            ?>
                            <?php
                                if($row['m']=="Mar")
                                {

                                ?>
                                <option value="Mar" selected="selected">Mar</option>  
                                <?php
                                }
                                else
                                {
                                ?>                              
                                <option value="Mar">Mar</option> 
                                <?php
                                }
                            ?>
                            <?php
                                if($row['m']=="Apr")
                                {

                                ?>
                                <option value="Apr" selected="selected">Apr</option>  
                                <?php
                                }
                                else
                                {
                                ?>                              
                                <option value="Apr">Apr</option> 
                                <?php
                                }
                            ?>



                            <option value="May">May</option>
                            <option value="Jun">Jun</option>
                            <option value="Jul">Jul</option>
                            <option value="Aug">Aug</option>
                            <option value="Sep">Sep</option>
                            <option value="Oct">Oct</option>
                            <option value="Nov">Nov</option>
                            <option value="Dec">Dec</option>
                        </select>
                        <select name="y">
                            <option value="<?php echo $r1[6]?>" id="c" selected="selected">Yea</option>
                            <?php
                                for($i=2012;$i>=1950;$i--)
                                {
                                    if($row['y']==$i)
                                    {
                                    ?>
                                    <option value="<?php echo $i?>" selected="selected"><?php echo $i?></option>
                                    <?php
                                    }
                                    else
                                    {
                                    ?>
                                    <option value="<?php echo $i?>"><?php echo $i?></option>
                                    <?php
                                    }
                                }
                            ?>
                        </select>
                    </td>
                </tr>
                        
                        
                        
                        
                        
                        
                        <tr>
                            <td>Salary:</td>
                            <td width="66%"><input type="text" name="sl" value="<?php echo $r1[7]?>"  id="sa" class="text" style="width:300px;"></td>
                        </tr>
                        
                        
                        <tr>
                            <td>Contact No:</td>
                            <td width="66%"><input type="text" name="cn" value="<?php echo $r1[8]?>"  id="cno" class="text" style="width:300px;"></td>
                        </tr>
                      
                        <tr>
                            <td>Email:</td>
                            <td width="66%"><input type="text" name="em" value="<?php echo $r1[9]?>"  id="mail" class="text" style="width:300px;"></td>
                        </tr>    
                               <tr>
                                 <td>Location:</td>
                                <td width="67%" align="left">
                                    <select name="lo" value="<?php echo $r1[10]?>" id="loc" style="width:300px;" onChange="occu1()">
                                    <option selected="selected" value="">Select</option>



 



                                    <option value="Navsari">Navsari</option>
                                    <option value="Ahemdbad">Ahemdbad</option>
                                    <option value="Valsad">Valsad</option>
                                    <option value="Vadodara">Vadodara</option>
                                    <option value="Bharuch">Bharuch</option>
                                    <option value="Vapi">Vapi</option>
                                    <option value="Bilimora">Bilimora</option>   
                                    <option value="Bardoli">Bardoli</option>
                                    <option value="Surat">Surat</option>


                                    <option value="Others">Others</option>
                                    </select>
                                    &nbsp;</td>
                            </tr>
                             <tr>
                    <td>Last date</td>
                    <td>
                        <select name="day">
                            <option value="<?php echo $r1[11]?>" id="d" selected="selected">Day</option>
                            <?php
                                for($i=1;$i<=31;$i++)
                                {
                                    if($row['day']== $i)
                                    {
                                    ?>
                                    <option value="<?php echo $i?>" selected="selected"><?php echo $i?></option>
                                    <?php
                                    }
                                    else
                                    {
                                    ?>
                                    <option value="<?php echo $i?>"><?php echo $i?></option>
                                    <?php
                                    }
                                }
                            ?>
                        </select>




                        <select name="month">
                            <option value="<?php echo $r1[12]?>" id="m" selected="">Month</option>
                            <?php
                                if($row['month']=="Jan")
                                {

                                ?>
                                <option value="Jan" selected="selected">Jan</option>  
                                <?php
                                }
                                else
                                {
                                ?>                              
                                <option value="Jan">Jan</option> 
                                <?php
                                }
                            ?>
                            <?php
                                if($row['month']=="Feb")
                                {

                                ?>
                                <option value="Feb" selected="selected">Feb</option>  
                                <?php
                                }
                                else
                                {
                                ?>                              
                                <option value="Feb">Feb</option> 
                                <?php
                                }
                            ?>
                            <?php
                                if($row['month']=="Mar")
                                {

                                ?>
                                <option value="Mar" selected="selected">Mar</option>  
                                <?php
                                }
                                else
                                {
                                ?>                              
                                <option value="Mar">Mar</option> 
                                <?php
                                }
                            ?>
                            <?php
                                if($row['month']=="Apr")
                                {

                                ?>
                                <option value="Apr" selected="selected">Apr</option>  
                                <?php
                                }
                                else
                                {
                                ?>                              
                                <option value="Apr">Apr</option> 
                                <?php
                                }
                            ?>



                            <option value="May">May</option>
                            <option value="Jun">Jun</option>
                            <option value="Jul">Jul</option>
                            <option value="Aug">Aug</option>
                            <option value="Sep">Sep</option>
                            <option value="Oct">Oct</option>
                            <option value="Nov">Nov</option>
                            <option value="Dec">Dec</option>
                        </select>
                        <select name="year">
                            <option value="<?php echo $r1[13]?>" id="y" selected="selected">Year</option>
                            <?php
                                for($i=2012;$i>=1950;$i--)
                                {
                                    if($row['year']==$i)
                                    {
                                    ?>
                                    <option value="<?php echo $i?>" selected="selected"><?php echo $i?></option>
                                    <?php
                                    }
                                    else
                                    {
                                    ?>
                                    <option value="<?php echo $i?>"><?php echo $i?></option>
                                    <?php
                                    }
                                }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                           
                                                                        
                            <tr>
                                <td>Job Type:</td>
                                <td width="67%" align="left">
                                    <select name="jt" value="<?php echo $r1[14]?>" id="jot" style="width:300px;" onChange="occu1()">
                                        <option selected="selected" value="">Select</option>


                                        <option value="Full Time">Full Time</option>
                                        <option value="Part Time">Part Time </option>
                                        <option value="Full/Part Time">Full/Part Time</option>
                                    </select>
                                    &nbsp;</td>
                            </tr>
                     <tr>
                     <?php
                            if($_REQUEST['jpid'])
                            {
                            ?>
                            <tr>
                                <td></td>
                                <td align="center">
                                <input type="submit" name="update" value="Change"onClick="return mesg(this.form);"/>   
                                <td>
                            </tr>

                            <?php 
                            }
                            else
                            {
                            ?>
                            <tr>
                                <td></td>
                                <td align="center">
                                <input type="submit" name="save" value="Save"onClick="return mesg(this.form);"/>   
                                <td>
                            </tr>

                            <?php 
                            }
                        ?>         
                              
</table>
                       
                        </form>  </p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
               <li><a href="adminhome.php">Main Page</a></li>
                    <li><a href="adminemployer.php">View Employer</a></li>
                    <li><a href="adminjobseeker.php">View Jobseeker</a></li>
                    <li><a href="adminviewjob.php">View Job</a></li>
                    <li><a href="adminjobpost.php">Add Job</a></li>
                    <li><a href="adminfeedback.php">VIew Feedback</a></li>
                        <li class="last"><a href="index.php">Logout</a> </li>  

          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
