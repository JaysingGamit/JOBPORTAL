<?php                    
    error_reporting(0);
	session_start();    ob_start();
    include('conn.php');
    if(isset($_REQUEST['submit']))
    {
        //echo "hello";
        // $emp_id=$_REQUEST[''];
        $username=$_REQUEST['uname'];
        $password=$_REQUEST['pass'];
        $address=$_REQUEST['add'];
        $emailid=$_REQUEST['email'];
        $languagesknown=implode(",",$_REQUEST['che']);
        $dob=$_REQUEST['dob']; 
        $gender=$_REQUEST['name']; 
        $maritalstatus=$_REQUEST['name1'];
        $country=$_REQUEST['country'];
        $state=$_REQUEST['state']; 
        $city=$_REQUEST['city'];
        $phoneno=$_REQUEST['phoneno']; 
       
        echo $sql="INSERT INTO jobseeker(uname,password,address,emailid,languagesknown,date,gender,maritalstatus,co_id,s_id,c_id,phoneno) 
        VALUES ('$username','$password','$address','$emailid','$languagesknown','$dob','$gender','$maritalstatus','$country','$state','$city','$phoneno')";

        $t=mysql_query($sql) or die(mysql_error());

        echo "data insert";
        header('location:Jobseeker.php');
    }

    if(isset($_REQUEST['j_id']))
    {
        $id=$_REQUEST['j_id'];
        $sel="select * from jobseeker where j_id='$id'";     
        $res=mysql_query($sel);
        $r=mysql_fetch_array($res);
    }
    if(isset($_REQUEST['update']))
    {
        $id=$_REQUEST['j_id']; 
        $username=$_REQUEST['uname'];
        $password=$_REQUEST['pass'];
        $address=$_REQUEST['add'];
        $emailid=$_REQUEST['email'];
        $languagesknown= implode(",",$_REQUEST['che']);   
        $dob=$_REQUEST['dob']; 
        $gender=$_REQUEST['name']; 
        $maritalstatus=$_REQUEST['name1'];
        $country=$_REQUEST['country'];
        $state=$_REQUEST['state']; 
        $city=$_REQUEST['city'];
        $phoneno=$_REQUEST['phoneno']; 

        $u="update jobseeker set uname='$username',password='$password
        ',address='$address',emailid='$emailid',languagesknown='$languagesknown',date='$dob',gender='$gender',maritalstatus='$maritalstatus',co_id='$country',s_id='$state',c_id='$city',phoneno='$phoneno' where j_id='$id'";
        mysql_query($u);
        header("location:Job Seeker.php");
    }
                    

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>jobseereg</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<script type="text/javascript">

        function mesg(form)
        {     

            var uname=document.getElementById('uname');
       	    var pass=document.getElementById('pass');     
            var add=document.getElementById('add');       
            var email=document.getElementById('email');
            var ck=document.getElementById('chk');
            var name=document.getElementById('name');
            var name1=document.getElementById('name1');
            var country=document.getElementById('country');      
            var state=document.getElementById('state');
            var city=document.getElementById('city');
            var phoneno=document.getElementById('phoneno');



            var alpha = /^[a-zA-Z' _]+$/;
            var pa = /^[a-zA-Z0-9'_]+$/;
            var em = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;   
            var haschecked=false;
            var tel_no=/^[\d]{6,10}$/;

            if(uname.value == '')
                {
                alert("Please fill up the username");
                uname.focus();
                return false;
            } 

            else if(!alpha.test(uname.value))
                {

                alert("Please enter user name is Charcter values");
                uname.focus();
                uname.value='';
                return false;
            } 


            else if(pass.value=='')
                {
                alert("plese fill up the password");
                pass.focus();
                return false;
            }
            else if(!pa.test(pass.value))
                {

                alert("please enter Charcter values");
                pass.focus();
                pass.value='';
                return false;
            }

            else if(add.value=='')
                {
                alert("plese fillup the address");
                add.focus();
                return false;
            }
            else if(email.value=='')
                {

                alert("Please fill the email");
                email.focus();
                return false;

            }
            else if(!em.test(email.value))
                {
                alert("Please enter valid Emailid");
                email.value= '';
                email.focus();
                return false;

            }

            for(var i=0;i < ck.length;i++)
                {
                if(ck[i].checked)
                    {
                    haschecked=true;
                    break;   
                }
            }
            if((form.chk[0].checked==false) &&(form.chk[1].checked==false) && (form.chk[2].checked==false))
                {

                alert("Please fill the language");
                name.focus();
                return false;

            }
            if(dob.value=='')
                {
                alert("plese fill up the date of birth");
                dob.focus();
                return false;
            }


            if((form.name[0].checked==false) &&(form.name[1].checked==false))
                {

                alert("Please fill the gender");
                name.focus();
                return false;

            }

            if((form.name1[0].checked==false) &&(form.name1[1].checked==false))                 
                {

                alert("Please fill the Maritalstatus");
                name1.focus();
                return false;

            }
            if(country.value=='')
                {
                alert("please fill up the Country");
                country.focus();
                return false;
            }
            if(state.value=='')
                {
                alert("please fill up the State");
                state.focus();
                return false;
            }

            if(city.value=='')
                {
                alert("please fill up the City");
                city.focus();
                return false;
            }

            else if(phoneno.value=='')
                {

                alert("Please fill the phoneno");
                phoneno.focus();
                return false;

            }
            if(!tel_no.test(phoneno.value))
                {
                alert("Invalid Telephone Number..");
                return false;
            }   



            else
                {
                return true;
            }
        }                     

    </script>     
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
             <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         <!-- <li><a href="employee.php"><span>Employee</span></a></li>
-->          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
?>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <!--<span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
-->        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
       <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   
      <!--<h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-style:inherit;color:#00F";>Career.Com</span> <small>Company Slogan Here</small></a></h1>
      -->        </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> 
         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a>
                       
         </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
         <!-- <h2><span>Excellent Solution</span> For Your Business</h2>
          <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>-->
          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="640" height="188" alt="" class="fl" /></div>
          <div class="post_content">
            <p>      <form name=good method="post" enctype="multipart/form-data"> 
                    <br>
                    <table width="575" height="954"   border="2"cellpadding="10" cellspacing="10" style="margin-left:280;">

                    <tr>
                        <td align="center" colspan="2"><font size="6" face="Times New Roman, Times, serif" color="#2695C3"><b>Job Seeker Registration </b></font></td>
                    </tr>

                    <tr>
                        <td width="75">User Name:</td>
                        <td width="302"><input type="text" name="uname"  id="uname" value="<?php echo $r[1]?>"></td>
                    </tr>

                    <tr>
                        <td>password:</td>
                        <td><input type="password" name="pass" id="pass" value="<?php echo $r[2]?>"/></td>
                    </tr>

                    <tr>
                        <td>Address:</td>
                        <td><textarea rows="3" cols="18" name="add" id="add"><?php echo $r[3]?></textarea></td>
                    </tr>

                    <tr>
                        <td>Email id</td>
                        <td><input type="text" name="email" id="email" value="<?php echo $r[4]?>"/></td>
                    </tr>

                    <tr>
                        <td>Languages Known:</td>

                      <!--  <td><?php            //gujarati
                                if(isset($_REQUEST['edit']))
                                {
                                    $ty=$fetch['che'];
                                    $x=explode(",",$ty);
                                    if($x[0]=='gujarati')
                                    {
                                    ?>

                                    <input type="checkbox" name="che[]" value="gujarati" checked="checked">gujarati
                                    <?php
                                    }
                                    else
                                    {
                                    ?>
                                    <input type="checkbox" name="che[]" value="gujarati">gujarati 
                                    <?php
                                    }
                                ?>

                                <?php          //Hindi
                                    if($x[0]=='Hindi' || $x[1]=='Hindi')
                                    {
                                    ?>
                                    <input type="checkbox" name="che[]" value="Hindi" checked="checked">Hindi
                                    <?php
                                    }

                                    else
                                    {
                                    ?>
                                    <input type="checkbox" name="che[]" value="Hindi">Hindi
                                    <?php
                                    }
                                ?>

                                <?php          //English
                                    if($x[0]=='English' || $x[1]=='English' || $x[2]=='English')
                                    {
                                    ?>
                                    <input type="checkbox" name="che[]"  value="English " checked="checked">English
                                    <?php
                                    }

                                    else
                                    {                                                       
                                    ?>
                                    <input type="checkbox" name="che[]" value="English">English
                                    <?php
                                    }
                                }
                                else
                                {
                                ?>
                                <input type="checkbox" name="che[]" value="<?php echo $r[5]?>" id="chk">gujarati  
                                <input type="checkbox" name="che[]" value="<?php echo $r[5]?>" id="chk">Hindi   
                                <input type="checkbox" name="che[]" value="<?php echo $r[5]?>" id="chk">English

                                <?php
                                }    

                            ?>

                        </td>   -->
                        <td>
                        <input type="checkbox" name="che[]" value="gujarati"> gujarati
                        <input type="checkbox" name="che[]" value="Hindi"> Hindi 
                        <input type="checkbox" name="che[]" value="English"> English 
                    </td>

                    </tr>



                    <tr>
                        <td>
                            DOB:
                        </td>
                        <td class="text" valign="middle">

                            <input type="text" name="dob" id="dob" class="280px-field" size="44" value="<?php echo $r[6]?>"">

                            </td>




                            <tr>
                            <td>Gender:</td>
                            <?php
                                if($r['gender']=="male")
                                {
                                ?>                                                                          
                                <td><input type="radio" name="name" id="name" value="Male" checked="checked">Male 
                                <input type="radio" name="name" id="name" value="Female">Female</td>
                                <?php
                                }
                                else if($r['gender']=="female")
                                    {
                                    ?>
                                    <td width="33"><input type="radio" name="name" id="name" value="Male">Male 
                                    <input type="radio" name="name" id="name" value="Female"  checked="checked">Female</td>
                                    <?php 
                                    }
                                    else
                                    {
                                    ?>
                                    <td width="23"><input type="radio" name="name" id="name" value="Male">Male 
                                    <input type="radio" name="name" id="name" value="Female">Female</td>
                                    <?php
                                }
                            ?>
                            </tr>

                            <tr>
                            <td>Maritalstatus</td>
                            <td><input type="radio" name="name1" id="name1" value="married" />married
                            <input type="radio" name="name1" id="name1" value="unmarried" />unmarried </td>
                            </tr>
                            <tr>
                            <td>Country:</td>
                            <td><input type="text" name="country"  id="country" value="<?php echo $r[9]?>"></td>
                            </tr>



                            <tr>
                            <td>state</td> 
                            <td><input type="text" name="state"  id="state" value="<?php echo $r[10]?>""></td>
                    </tr>


                    <tr>
                        <td>city</td>
                        <td><input type="text" name="city"  id="city" value="<?php echo $r[11]?>""></td>
                            </tr>          


                            <tr>
                            <td>Phone No:</td>
                            <td><input type="text" name="phoneno" id="phoneno" value="<?php echo $r[12]?>"" /></td>
                    </tr>

                   


                    <?php
                        if($_REQUEST['j_id'])
                        {
                        ?>
                        <td>
                        </td>
                        <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="update" value="Update" onClick="return mesg(this.form);"/>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" name="RESET" value="Reset" />
                        </td>  
                        <?php 
                        }
                        else
                        {
                        ?>
                        <td>
                        </td>
                        <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="submit" name="submit" value="Submit" onClick="return mesg(this.form);"/>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="reset" name="RESET" value="Reset" />
                        </td>  
                        <?php 
                        }
                    ?>
                    </tr>

                    </table>



                </form> </p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
             <?php
    if($_SESSION['uname'])
    {
        ?>
         <li><a href="Home.php">Main Page</a></li>
                    <li><a href="jobseeker_home.php?uname=<?php echo $uname?>">Account Detail</a></li>
                    <li><a href="jseeker_pass_change.php?uname=<?php echo $uname?>">Change Password </a></li>
                    <li><a href="Post Resume.php?uname=<?php echo $uname?>">Resume</a></li>
                    <li><a href="eresume.php?uname=<?php echo $uname?>">Show Resume</a></li>
                    <li><a href="search job1.php?uname=<?php echo $uname?>">Job Search</a></li>
                    <li><a href="feed back1.php?uname=<?php echo $uname?>">Feed Back </a></li>
                    <li><a href="Contact.php?uname=<?php echo $uname?>">Contact Us</a></li>
                    
                    <li class="last"><a href="logout.php">Logout</a></li>
        <?php 
    }
    else
    {
        ?>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employee</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        <?php 
    }
?>
          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
