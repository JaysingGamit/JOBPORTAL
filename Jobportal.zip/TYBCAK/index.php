<?php
	error_reporting(0);
	session_start();        
    include('conn.php');     
    $id=$_REQUEST['eid'];
    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname']; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="gu">
<head>
<title>index</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<link rel="stylesheet" type="text/css" href="anylinkmenu.css" />
<link rel="stylesheet" type="text/css" href="style.css" />


<script type="text/javascript" src="menucontents.js"></script>

<script type="text/javascript" src="anylinkmenu.js">

/***********************************************
* AnyLink JS Drop Down Menu v2.0- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Project Page at http://www.dynamicdrive.com/dynamicindex1/dropmenuindex.htm for full source code
***********************************************/

</script>

<script type="text/javascript">

//anylinkmenu.init("menu_anchors_class") //Pass in the CSS class of anchor links (that contain a sub menu)
anylinkmenu.init("menuanchorclass")

</script>
</head>
<body>
<div>
  <h4><a href="employee.php" style="color: black;font-size: 20px;">નિયોજક</a></h4>
  <h4><a href="admin.php"  style="color: black;font-size: 20px;margin-left: 800px;">સંચાલક</a></h4>
       </div>
       
<div class="main" style="margin-top:-60px">
  <div class="header">
    <div class="header_resize">
    
<!--4th anchor link-->

      <div class="menu_nav">	
        <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php?uname=<?php echo $uname?>"><span>પ્રથમપાનું</span></a></li>
         <li><a href="jobs.php" class="menuanchorclass" rel="anylinkmenu4" style="font-style:inherit;color:#FFF">Jobs</a></li>
          <li><a href="jobseeker.php" style="font-style:inherit;color:#FFF"><span>રોજગાર શોધક</span></a></li>
          <li><a href="About.php?uname=<?php echo $uname?>"><span>વિશેષ માહિતી</span></a></li>
          <li><a href="contact.php?uname=<?php echo $uname?>"><span>સંપર્ક</span></a></li>
          
        </ul>
        
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>પ્રથમપાનું</span></a></li>
          <!--<li><a href="employee.php"><span>Employer</span></a></li>
          
-->
<li><a href="jobs.php" class="menuanchorclass" rel="anylinkmenu4" style="font-style:inherit;color:#FFF">નોકરીઓ</a></li>
          <li><a href="jobseeker.php" style="font-style:inherit;color:#FFF"><span>રોજગાર શોધક</span></a></li>
          <li><a href="About.php"><span>વિશેષ માહિતી</span></a></li>
          <li><a href="contact.php" style="font-style:inherit;color:#FFF"><span>સંપર્ક</span></a></li>
                   
        </ul>
        <?php 
    }
?>
        
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <!--<span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>-->
          <!--<input name="button_search" src="images/search.gif" class="button_search" type="image" />-->
        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
      <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>

      <!--<h1><a href="index.html">Career<span>.Com</span> <small>Company Slogan Here</small></a></h1>
      --> <!-- <h1 style="font-size:40px;color:#00C;"><a href="index.html">  
</small></a></h1>-->
        
      </div><a href="#">

      <p>&nbsp;</p>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider">
        <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a>

        
        </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">

          <div class="clr"></div>
          <div class="img"><img src="images/mp.jpg" width="640" height="188" alt="" class="fl" /></div>
          <div class="post_content">
           
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
         <marquee behavior="alternate"><font size="3px" color="#FF0000">નોકરી ઓફ ગુજરાત</font>
         <h3  style="font-size:20px;color:#C3C;">
          </h3></marquee><p align="justify"> <span class="style2" style="font-family:Tahoma, Geneva, sans-serif; font-weight:normal;color:#300
         ; font-size:15px; ">નોકરી ઓફ ગુજરાત મા આપ નુ સ્વાગત છે.આ વેબસાઇટ તેના લાયકાત મુજબ વિવિધ નોકરી શોધવા માટે જોબ શોધ કરવાની સુવિધા પૂરી પાડે છે.આ વેબસાઇટ પોતે રજીસ્ટર અને તેમના શૈક્ષણિક માહિતી સાથે તમે પ્રોફાઇલ બનાવી શકો છો તેમજ નોકરી શોધવા અને નોકરી માટે અરજી કરી શકો છો.</span></p>
              <p align="justify"><span class="style2" style="font-family:Tahoma, Geneva, sans-serif; font-weight:normal; font-size:15px;color:#300">આ વેબસાઈટ પણ વિવિધ નોકરીદાતા જેઓ તેમની સંસ્થામાં માં કર્મચારીઓની ભરતી કરવા માટે જરૂરી માટે બનાવાયેલ છે. આ વેબસાઈટ પર પોતે રજીસ્ટર અને તેમણે તેમના સંસ્થા વિવિધ કામ ખાલી જગ્યાઓ ની માહિતી અપલોડ કરી શકે છે. તેમજ નિયોક્તા નોકરી ના કાર્યક્રમો જોવા અને નોકરી ઓફ ગુજરાત્ માટે સૂચના પત્ર મોકલી શકો છો.</span></p>
        
        
          <div class="clr"></div>
          <div class="img"><!--<img src="images/mp.jpg" width="640" height="188" alt="" class="fl" />--></div>
          <div class="post_content">
           
     
          </div>
          <div class="clr"></div>
        </div>
      </div>
      <div class="sidebar">
            <div class="gadget">
             સાઇડબાર મેનુ
              <h2 class="star"><span <h2 style="font-size:24px;color:#000;"></span></h2>
              <div class="clr"></div>
              <ul class="sb_menu">
                    <li class="active"><a href="index.php"><span>પ્રથમપાનું</span></a></li>
             <!-- <li><a href="employer.php"><span>Employer</span></a></li>-->
              <li><a href="jobseeker.php"><span>રોજગાર શોધક</span></a></li>
              <!--<li><a href="admin.php"><span>Admin</span></a></li>
    -->          <li><a href="About.php"><span>માહિતી</span></a></li>
              <li><a href="contact.php"><span>સંપર્ક</span></a></li>
              </ul>
            </div>
        
        <div class="gadget">
         
        </div>
      </div>
      <div class="clr">
     
      
      </div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
       <!-- <h2 style="font-size:25px;color:#309;"><span>Image</span> Gallery</h2>
-->        <!--<a href="#"><img src="images/part.jpg" width="75" height="75" alt="" class="gal" /></a>--> <!--<a href="#"><img src="images/kp.jpg" width="75" height="75" alt="" class="gal" /></a>--><!--<a href="#"><img src="images/sai.jpg" width="75" height="75" alt="" class="gal" /></a>--><a href="#">

<a href="#"><img src="images/kg.jpg" width="250" height="250" alt="" class="gal" /></a>

        <!--<a	 href="#"><img src="images/pk.jpg" width="75" height="75" alt="" class="gal" /></a>
        <img src="images/sai.jpg" width="75" height="75" alt="" class="gal" /></a><a href="#"><img src="images/pk.jpg" width="75" height="75" alt="" class="gal" /></a>--> </div>
             <div class="col c2">
<a href="#"><img src="images/l1.jpg" width="250" height="250" alt="" class="gal" /></a>



     <!-- <h2><span>Contact</span> Us</h2>
        <p class="contact_info"> <span>Name:</span>Krupa Patel<br />
 <p class="contact_info"> <span>Address:</span>Sadakpor,Hanuman faliya</br></br>
 Ta:Chikhli
 Dist:Navsari
 <br /></br>
          <span>Mobile No:</span>7096923068<p class="contact_info">
                    <span>Email:</span>Krupa@gmail.com<p class="contact_info">

     --> 
      
      
      
      
       <!-- <h2><span>Contact</span>Us</h2>-->
       <!--<h2 style="font-size:24px;color:#309;"><span>Contact</span> 
       Us</h2> 
        <p class="contact_info"> <span>Name:</span>Khushbu Mistry<br />
        <p class="contact_info"><span>Address:</span>Talavchora,Suthar faliya                
        <p class="contact_info">Ta: ChikhliDist:  Navsari<br />
          </br>
          Mobile No:834780341       -->                            
 <p class="contact_info">
   
   
   
   
   
   
   <!--<p>Curabitur sed urna id nunc pulvinar semper. Nunc sit amet tortor sit amet lacus sagittis posuere cursus vitae nunc.Etiam venenatis, turpis at eleifend porta, nisl nulla bibendum justo.</p>-->
   <!--<ul class="fbg_ul">
          <li><a href="#">Lorem ipsum dolor labore et dolore.</a></li>
          <li><a href="#">Excepteur officia deserunt.</a></li>
          <li><a href="#">Integer tellus ipsum tempor sed.</a></li>
        </ul>
-->   </div>
      <div class="col c3">
      <a	 href="#"><img src="images/j.jpg" width="250" height="250" alt="" class="gal" /></a>
        
      
        <!--<h2><span>Contact</span> Us</h2>
        <p>Nullam quam lorem, tristique non vestibulum nec, consectetur in risus. Aliquam a quam vel leo gravida gravida eu porttitor dui.</p>-->
        <!--<p class="contact_info"> <span>Address:</span> 1458 TemplateAccess, USA<br />
          <span>Telephone:</span> +123-1234-5678<br />
          <span>FAX:</span> +458-4578<br />
          <span>Others:</span> +301 - 0125 - 01258<br />
-->         <!-- <span>E-mail:</span> <a href="#">mail@yoursitename.com</a> </p>
-->      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf"><a href="#">નોકરી ઓફ ગુજરાત</a>.</p>
      <p class="rf"> <a href="http://www.dreamtemplate.com/"></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
