-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2015 at 07:21 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker`
--

CREATE TABLE IF NOT EXISTS `jobseeker` (
  `j_id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `address` varchar(250) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `languagesknown` varchar(50) NOT NULL,
  `date` varchar(25) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `maritalstatus` varchar(20) NOT NULL,
  `co_id` varchar(25) NOT NULL,
  `s_id` varchar(25) NOT NULL,
  `c_id` varchar(25) NOT NULL,
  `phoneno` varchar(25) NOT NULL,
  `compro` varchar(50) NOT NULL,
  `language` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`j_id`),
  KEY `co_id` (`co_id`),
  KEY `s_id` (`s_id`),
  KEY `c_id` (`c_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT AUTO_INCREMENT=130 ;

--
-- Dumping data for table `jobseeker`
--

INSERT INTO `jobseeker` (`j_id`, `uname`, `password`, `address`, `emailid`, `languagesknown`, `date`, `gender`, `maritalstatus`, `co_id`, `s_id`, `c_id`, `phoneno`, `compro`, `language`, `status`) VALUES
(128, 'krina', '11', 'jg', 'krinamistry05@gmail.com', '', '2/12/2013', 'Female', 'married', 'eqr', 'reqr', 'eqrqer', '333434', 'Basic operations', 'Malayalam', '0'),
(129, 'a', 'a', '212,Hormezed bag\r\nGoharbag', 'krinamistry05@gmail.com', 'gujarati', '2/12/2013', 'Female', 'married', 'eqr', 'India', 'Bilimora', '07802030713', '', '', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
