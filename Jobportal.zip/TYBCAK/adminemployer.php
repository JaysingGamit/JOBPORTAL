<?php                       
error_reporting(0);
ob_start();
    session_start();        
    include('conn.php');     
    $uname=$_SESSION['username']; 
    $s="select * from employer";
    $r1=mysql_query($s);

    if(isset($_REQUEST['eid']))
    {
        $id=$_REQUEST['eid'];
        $del="delete from employer where eid='$id'";
        mysql_query($del);
        header("location:adminemployer.php");
        } 
           if(isset($_REQUEST['s']))
    {
        $eid = $_REQUEST['s'];

        $select = "select * from employer where eid = '$eid'";
        $result = mysql_query($select);
        $row = mysql_fetch_array($result);

        if($row['status']=="enable")
        {
            $k = "disable";
            $update = "update employer set status = '$k' where eid = '$eid'";
            mysql_query($update);
            header("location:adminemployer.php");
        }
        else if($row['status']=="disable")
            {
                $k = "enable";
                $update = "update employer set status = '$k' where eid = '$eid'";
                mysql_query($update);
                header("location:adminemployer.php");
            }

    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>adminjobseeker</title> 
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
       <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>

<script type="text/javascript">
$(document).on('click','.status_checks',function(){
      var status = ($(this).hasClass("btn-success")) ? '0' : '1';
      var msg = (status=='0')? 'Deactivate' : 'Activate';
      if(confirm("Are you sure to "+ msg)){
        var current_element = $(this);
        url = "ajax1.php";
        $.ajax({
          type:"POST",
          url: url,
          data: {id:$(current_element).attr('data'),status:status},
          success: function(data)
          {   
            location.reload();
          }
        });
      }      
    });
</script>
<style type="text/css">
.btn-success {
   background-color: #65B688;
   border-color: #65B688;
   }
   .btn-danger {
   color: #fff;
   background-color: #d9534f;
   border-color: #d43f3a;
   }
   .btn {
   color: white;
   display: inline-block;
   margin-bottom: 0;
   font-weight: 400;
   text-align: center;
   vertical-align: middle;
   cursor: pointer;
   background-image: none;
   border: 1px solid transparent;
   white-space: nowrap;
   padding: 6px 12px;
   font-size: 14px;
   line-height: 1.42857143;
   border-radius: 4px;
   -webkit-user-select: none;
   -moz-user-select: none;
   -ms-user-select: none;
   user-select: none;
   }

</style>
    </head>
    <body>
        <div class="main">
            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <?php
                            if($_SESSION['uname'])
                            {
                            ?>
                            <ul>
                                <li class="active"><a href="index.php"><span>Home</span></a></li>

                                <li><a href="About.php"><span>About</span></a></li>
                                <li><a href="contact.php"><span>Contact Us</span></a></li>
                            </ul>
                            <?php 
                            }
                            else
                            {
                            ?>
                            <ul>
                                <li class="active"><a href="index.php"><span>Home</span></a></li>
                                <li><a href="employee.php"><span>Employer</span></a></li>
                                <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
                                <li><a href="About.php"><span>About</span></a></li>
                                <li><a href="contact.php"><span>Contact Us</span></a></li>
                            </ul>
                            <?php 
                            }
                        ?>
                    </div>
                    <div class="searchform">
                        <form id="formsearch" name="formsearch" method="post" action="#">
                            <!--<span>
                                <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
                            </span>
                            <input name="button_search" src="images/search.gif" class="button_search" type="image" />-->
                        </form>
                    </div>
                    <div class="clr"></div>
                    <div class="logo">
                    <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
       
                      <!--  <h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-style:inherit;color:#00F";>Career.Com</span> <small>Company Slogan Here</small></a></h1>
                    --></div>
                    
                    <div class="clr"></div>
                    <div class="slider">
                        <div id="coin-slider">
                         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /></a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a></div>
                       
                         </div>
                        <div class="clr"></div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
                    <div class="clr"></div>
                  
                    <div class="clr"></div>
                </div>
            </div>
            <div class="content">
                <div class="content_resize">
                    <div class="mainbar">
                        <div class="">
                            <!--<h2><span>Excellent Solution</span> For Your Business</h2>-->
                            <!--<p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>-->
                           <!-- <div class="clr"></div>-->
                            <div class="post_content">
                           <marquee behavior="alternate"><h3 style="font-size:24px;color:red;">Employee Information</h3></marquee>
                                <p>       <form name="" method="post">  
                     
 <table border="3" cellpadding="3" cellspacing="2" width="2"  style="margin-left:-90px;">
                            
                            <tr>
                                        <th width="11">Id</th> 
                                        <th width="38">First Name</th> 
                                        <th width="38">Last Name</th> 
                                        <th width="70">Business Type</th> 
                                        <th width="70">Business Name</th> 
                                        <th width="40">Email Id </th> 
                                        <th width="48">Mobile NO</th> 
                                        <th width="48" colspan="2">Action</th> 
                                         

                            </tr>

                                <?php           
                                    while($row=mysql_fetch_array($r1))   
                                    {
                                    ?>           


                                    <tr>
                                        <td><?php echo $row[0]?></td>
                                    
                                        <td><?php echo $row[1]?></td>  
                                    
                                         <td><?php echo $row[2]?></td>  
                     
                                                          
                                          <td><?php echo $row[5]?></td>  
                                          <td><?php echo $row[6]?></td>  
                                          <td><?php echo $row[7]?></td>  
                                        <td><?php echo $row[8]?></td>  

    <td><i data="<?php echo $row['eid'];?>" class="status_checks btn
  <?php echo ($row['status'])?
  'btn-success': 'btn-danger'?>"><?php echo ($row['status'])? 'Active' : 'Inactive'?>
 </i></td>                                
                                                                                                                                                                                            
  
                                     <td width="46"><a href="adminemployer.php?eid=<?php echo $row['eid']?>"> <input type="button" name="delete" value="Delete"></a></td> 
                                    

                                    </tr>

                                   
                                     </tr>
                                    <?php
                                    }

                                ?>


</table>
                        </form> </p>
                            </div>
                            <div class="clr"></div>
                        </div>
                        <div class="">


                            <div class="post_content">

                            </div>
                        </div>
                    </div>
                    <div class="sidebar">
                        <div class="gadget">
                            <h2 class="star"><span>Sidebar</span> Menu</h2>
                            <div class="clr"></div>
                            <ul class="sb_menu">
                                <li><a href="adminhome.php">Main Page</a></li>
                                <li><a href="adminemployer.php">View Employer</a></li>
                                <li><a href="adminjobseeker.php">View Jobseeker</a></li>
                                <li><a href="adminviewjob.php">View Job</a></li>
                                <li><a href="adminjobpost.php">Add Job</a></li>
                                <li><a href="adminfeedback.php">VIew Feedback</a></li>
                                <li class="last"><a href="index.php">Logout</a> </li>  

                            </ul>
                        </div>
                        <div class="gadget">
                            <div class="clr"></div>

                        </div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
            <div class="fbg">
                <div class="fbg_resize">

                </div>
            </div>
            <div class="footer">
                <div class="footer_resize">
                    <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
                    <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
                    <div style="clear:both;"></div>
                </div>
            </div>
        </div>
        <div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
