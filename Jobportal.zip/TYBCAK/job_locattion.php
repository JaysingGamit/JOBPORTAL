<?php 
	error_reporting(0);                   
    ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['j_id'];
    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname'];       
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>job_locattion</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
        <script type="text/javascript" src="js/cufon-yui.js"></script>
        <script type="text/javascript" src="js/cufon-titillium-600.js"></script>
        <script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
        <script type="text/javascript" src="js/script.js"></script>
        <script type="text/javascript" src="js/coin-slider.min.js"></script>
           <link rel="stylesheet" type="text/css" href="anylinkmenu.css" />

<script type="text/javascript" src="menucontents.js"></script>

<script type="text/javascript" src="anylinkmenu.js">

/***********************************************
* AnyLink JS Drop Down Menu v2.0- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Project Page at http://www.dynamicdrive.com/dynamicindex1/dropmenuindex.htm for full source code
***********************************************/

</script>

<script type="text/javascript">

//anylinkmenu.init("menu_anchors_class") //Pass in the CSS class of anchor links (that contain a sub menu)
anylinkmenu.init("menuanchorclass")

</script>  
    </head>
    <body>
        <div class="main">
            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <?php
                            if($_SESSION['uname'])
                            {
                            ?>
                             <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="jobs.php" class="menuanchorclass" rel="anylinkmenu4">Jobs</a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
                            <?php 
                            }
                            else
                            {
                            ?>
                               <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="jobs.php" class="menuanchorclass" rel="anylinkmenu4">Jobs</a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
                            <?php 
                            }
                        ?>
                    </div>
                    <div class="searchform">
                        <form id="formsearch" name="formsearch" method="post" action="#">
                            <span>
                                <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
                            </span>
                            <input name="button_search" src="images/search.gif" class="button_search" type="image" />
                        </form>
                    </div>
                    <div class="clr"></div>
                    <div class="logo">
                     <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   
                    <!--<h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-style:inherit;color:#00F";>Career.Com</span> <small>Company Slogan Here</small></a></h1>
                    -->    
                    </div>
                    <div class="clr"></div>
                    <div class="slider">
                        <div id="coin-slider">
                         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a>
                       
                         </div>
                        <div class="clr"></div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
            <div class="content">
                <div class="content_resize">
                    <div class="mainbar">
                        <div class="article" style="margin-left: -200px;">
                            <h2><span>All</span> Jobs</h2> </br>
                            <div class="clr"></div>
                            <div class="post_content" style="margin-left: -60px;">
                                <p>      <form >                   

                                        <?php
                                            $sel="select * from job_location";
                                            $res=mysql_query($sel);
                                            while($a=mysql_fetch_array($res))
                                            {
                                            ?>
                                            <div align="left" style="width: 600px;">
                                                <h3 ><a href="jobs.php?jpid=<?php echo $a['jl_id']?>" style="color: black;">Jobs in <?php echo $a[1]?></a></h3>


                                            </div>
                                            <?php 
                                            }
                                        ?>
                                </form> 
                                 </p>
                            </div>
                            <div class="clr"></div>
                        </div>


                    </div>
                </div>
            </div>
            <div class="sidebar">
                <div class="gadget">
                    <div class="clr"></div>

                </div>
                <div class="gadget">
                    <div class="clr"></div>

                </div>
            </div>
            <div class="clr"></div>
        </div>
        </div>
        <div class="fbg">
            <div class="fbg_resize">

            </div>
        </div>
        <div class="footer">
            <div class="footer_resize">
                <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
                <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
                <div style="clear:both;"></div>
            </div>
        </div>
        </div>
        <div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
