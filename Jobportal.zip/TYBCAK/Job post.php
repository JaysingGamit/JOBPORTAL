<?php  
	error_reporting(0);                  
    ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['eid'];
    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname'];                                                                        

    include('conn.php');
    if(isset($_REQUEST['save']))
    {
        //echo "hello";
        // $emp_id=$_REQUEST[''];  
        $companyname=$_REQUEST['companyname'];
        $jobtitle=$_REQUEST['job'];
        $l=$_REQUEST['l'];
        $postby=$_REQUEST['pb'];
        //$jobfunction=$_REQUEST['jf'];
        $jobdiscriptation=$_REQUEST['jo'];
        $da=$_REQUEST['sd'];
       
        $salary=$_REQUEST['sl'];
        $contactno=$_REQUEST['cn'];
        $email=$_REQUEST['em'];
        $location=$_REQUEST['lo'];  
        $day=$_REQUEST['ld'];
       
        $jobtype=$_REQUEST['jt'];
          $q=$_REQUEST['q'];
		$basic=$_REQUEST['basic'];
		$master=$_REQUEST['master'];	
        $e=$_REQUEST['e'];
		  
        $skill=$_REQUEST['skill'];

        $sql="insert into jobpost(company_name,j_ti,jl_id,p_by,j_ob,sal,co_no,e_mail,location,da,j_type,qua,basic,master,exp,skill)
        values('$companyname','$jobtitle','$l','$postby','$jobdiscriptation','$salary','$contactno','$email','$location','$day','$jobtype','$q','$basic','$master','$e','$skill')";

        $t=mysql_query($sql) or die(mysql_error());

        echo "data insert";
        header('location:Main Page.php');
    }
    if(isset($_REQUEST['jpid']))
    {
        $id=$_REQUEST['jpid'];
        $s="select * from jobpost where jpid='$id'";     
        $s=mysql_query($s);
        $r1=mysql_fetch_array($s);
    }
    if(isset($_REQUEST['update']))
    {
        $id=$_REQUEST['jpid'];
        $jobtitle=$_REQUEST['job'];
        $postby=$_REQUEST['pb'];
       // $jobfunction=$_REQUEST['jf'];
        $jobdiscriptation=$_REQUEST['jo'];
        $da=$_REQUEST['d'];
        $mont=$_REQUEST['m']; 
        $yea=$_REQUEST['y']; 
        $salary=$_REQUEST['sl'];
        $contactno=$_REQUEST['cn'];
        $email=$_REQUEST['em'];
        $location=$_REQUEST['lo'];  
        $day=$_REQUEST['day'];
        $month=$_REQUEST['month'];
        $year=$_REQUEST['year']; 
        $jobtype=$_REQUEST['jt']; 
        $q=$_REQUEST['q'];
		$basic=$_REQUEST['basic'];
		$master=$_REQUEST['master'];	
        $e=$_REQUEST['e'];
		$skill=$_REQUEST['skill'];
        $u="update jobpost set j_ti='$jobtitle',p_by='$postby',j_ob='$jobdiscriptation',d_a='$da',m_o='$mont',y_e='$yea',sal='$salary',co_no='$contactno',e_mail='$email',location='$location',da='$day',mo='$month',ye='$year',j_type='$jobtype' where jpid='$id'";
        mysql_query($u);
        header("location:Job post.php");
    }
    if(isset($_REQUEST['jpid']))
    {
        $id=$_SESSION['jpid'];
        $s="select * from jobpost where jpid='$id'";     
        $s=mysql_query($s);
        $r1=mysql_fetch_array($s);
    }
    if(isset($_REQUEST['update']))
    {
        $id=$_REQUEST['jpid'];
		$companyname=$_REQUEST['company_name'];
        $jobtitle=$_REQUEST['job'];
        $postby=$_REQUEST['pb'];
        //$jobfunction=$_REQUEST['jf'];
        $jobdiscriptation=$_REQUEST['jo'];
        $da=$_REQUEST['d'];
        $mont=$_REQUEST['m']; 
        $yea=$_REQUEST['y']; 
        $salary=$_REQUEST['sl'];
        $contactno=$_REQUEST['cn'];
        $email=$_REQUEST['em'];
        $location=$_REQUEST['lo'];  
        $day=$_REQUEST['day'];
        $month=$_REQUEST['month'];
        $year=$_REQUEST['year']; 
        $jobtype=$_REQUEST['jt']; 


        $u="update jobpost set company_name='$companyname', j_ti='$jobtitle',p_by='$postby',j_fu='$jobfunction',j_ob='$jobdiscriptation',d_a='$da',m_o='$mont',y_e='$yea',sal='$salary',co_no='$contactno',e_mail='$email',location='$location',da='$day',mo='$month',ye='$year',j_type='$jobtype' where jpid='$id'";
        mysql_query($u);
        header("location:adminviewjob.php");
    }

    $se="select * from jobpost where jpid='$id'";     
    $s1=mysql_query($se);
    $r2=mysql_fetch_array($s1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Job post</title> 
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
        <script type="text/javascript" src="js/cufon-yui.js"></script>
        <script type="text/javascript" src="js/cufon-titillium-600.js"></script>
        <script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
        <script type="text/javascript" src="js/script.js"></script>
        <script type="text/javascript" src="js/coin-slider.min.js"></script>
        <script type="text/javascript">

            function mesg(form)
            {     
				var companyname=document.getElementById('company_name');
                var jobtitle=document.getElementById('job');
                var postby=document.getElementById('pb');     
                var jobfuction=document.getElementById('jf');     
                var jobdescriptation=document.getElementById('ad');         
                var d=document.getElementById('a');
                var m=document.getElementById('b');
                var y=document.getElementById('c');
                var sa=document.getElementById('sa');

                var contact=document.getElementById('cno');

                var email=document.getElementById('mail');
                var day=document.getElementById('d');
                var month=document.getElementById('m');
                var year=document.getElementById('y');      
                var jobtype=document.getElementById('jot');

                var pa = /^[0-9'_{10}]+$/; 
                var alpha = /^[a-zA-Z' _]+$/;
                var pho = /^\[10]+$/; 
                var em = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/; 
					
					if(companyname.value == '')
                    {
                    alert("Please fill up the companyname");
                    company_name.focus();
                    return false;
                } 
                else if(!alpha.test(companyname.value))
                    {

                    alert("Please enter  companyname is Charcter values");
                    company_name.focus();
                    companyname.value='';
                    return false;
                } 
				 if(job.value == '')
                    {
                    alert("Please fill up the Job Title");
                    job.focus();
                    return false;
                } 
                else if(!alpha.test(job.value))
                    {

                    alert("Please enter Job Title is Charcter values");
                    job.focus();
                    job.value='';
                    return false;
                } 


                if(pb.value == '')
                    {
                    alert("Please fill up the Post By");
                    pb.focus();
                    return false;
                } 
                else if(!alpha.test(pb.value))
                    {

                    alert("Please enter Post Job is Charcter values");
                    pb.focus();
                    pb.value='';
                    return false;
                } 


                if(jf.value == '')
                    {
                    alert("Please fill up the Job Function");
                    jf.focus();
                    return false;
                } 
                else if(!alpha.test(jf.value))
                    {

                    alert("Please enter Job Function is Charcter values");
                    jf.focus();
                    jf.value='';
                    return false;
                } 

                if(ad.value == '')
                    {
                    alert("Please fill up the Job Descriptation");
                    ad.focus();
                    return false;
                } 
                else if(!alpha.test(ad.value))
                    {

                    alert("Please enter Job Descriptation in Charecter");
                    ad.focus();
                    ad.value='';
                    return false;
                } 



                else if(sa.value=='')
                    {
                    alert("plese fill up the salary");
                    sa.focus();
                    return false;
                }
                else if(!pa.test(sa.value))
                    {

                    alert("please enter numeric values");
                    sa.focus();
                    sa.value='';
                    return false;
                }





                else if(cno.value=='')
                    {

                    alert("Please fill the contactno");
                    cno.focus();
                    return false;

                }
                else if(!pho.test(phoneno.value))
                    {
                    alert("invalid contact number");
                    cno.value= '';
                    cno.focus();
                    return false;

                }  


                else if(mail.value=='')
                    {

                    alert("Please fill the email");
                    mail.focus();
                    return false;

                }
                else if(!em.test(mail.value))
                    {
                    alert("Please enter valid Emailid");
                    mail.value= '';
                    mail.focus();
                    return false;

                }
					
			              
                    
             
                         }                     

        </script> 
    </head>
    <body>
        <div class="main">
            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <?php
                            if($_SESSION['uname'])
                            {
                            ?>
                            <ul>
                                <li class="active"><a href="index.php"><span>Home</span></a></li>

                                <li><a href="About.php"><span>About</span></a></li>
                                <li><a href="contact.php"><span>Contact Us</span></a></li>
                            </ul>
                            <?php 
                            }
                            else
                            {
                            ?>
                            <ul>
                                <li class="active"><a href="index.php"><span>Home</span></a></li>
                                <li><a href="employee.php"><span>Employer</span></a></li>
                                <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
                                <li><a href="About.php"><span>About</span></a></li>
                                <li><a href="contact.php"><span>Contact Us</span></a></li>
                            </ul>
                            <?php 
                            }
                        ?>
                    </div>
                    <div class="searchform">
                        <form id="formsearch" name="formsearch" method="post" action="#">
                            <span>
                                <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
                            </span>
                            <input name="button_search" src="images/search.gif" class="button_search" type="image" />
                        </form>
                    </div>
                    <div class="clr"></div>
                    <div class="logo">
                    <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                <!-- <h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-style:inherit;color:#00F";>Career.Com</span> <small>Company Slogan Here</small></a></h1>-->
                    </div>
                    <div class="clr"></div>
                    <div class="slider">
                        <div id="coin-slider">
                        <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a>

                         <!--<a href="#"><img src="images/slide1.jpg" width="918" height="310" alt="" /> </a> 
                         <a href="#"><img src="images/slide2.jpg" width="918" height="310" alt="" /> </a>
                          <a href="#"><img src="images/slide3.jpg" width="918" height="310" alt="" /> </a>--> </div>
                        <div class="clr"></div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
            <div class="content">
                <div class="content_resize">
                    <div class="mainbar">
                        <div class="article">
                            <!--<h2><span>Excellent Solution</span> For Your Business</h2>
                            <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>
-->                            <div class="clr"></div>
                            <div class="img"><img src="images/img1.jpg" width="640" height="188" alt="" class="fl" /></div>
                            <div class="post_content">
                                <p><font size="6" face="Times New Roman, Times, serif" color="#2695C3"><h1>&nbsp;&nbsp;Post a new job  here</h1></font></p> 

                                <p>  <form name=good method="post" enctype="multipart/form-data" style="margin-left:200 ;"> 

                                        <br>
                                        <table width="578" height="422" border="2" cellpadding="2" cellspacing="5">
                                         <tr>
                                                <td width="30%" >companyname:</td>
                                                <td><input name="companyname" value="<?php echo $r1[1]?>" class="text" id="company_name" style="width:300px;" type="text" ></td>
                                            </tr>

                                        
                                        
                                            <tr>
                                                <td width="30%" >Job Title:</td>
                                                <td><input name="job" value="<?php echo $r1[1]?>" class="text" id="job" style="width:300px;" type="text" ></td>
                                            </tr>
                                               <!-- <tr>
                                                    <td width="30%" >Job Location:</td>
                                                    <td>      <select name="l"><option value="">-Select Location-</option>
                                                            <?php
                                                                $s="select * from job_location";
                                                                $r=mysql_query($s);
                                                                while($a=mysql_fetch_array($r))
                                                                {
                                                                ?>
                                                                <option value="<?php echo $a[0]?>"><?php echo $a[1]?></option>
                                                                <?php    
                                                                }
                                                            ?>
                                                    </select>   </td>
                                                </tr>              -->
                                            <tr>
                                                <td>Post By:</td>
                                                <td width="69%"><input type="text" name="pb" value="<?php echo $r1[2]?>"  id="pb" class="text" style="width:300px;"></td>
                                            </tr>
                                           <?php /*?> <tr>
                                                <td>Job Function: </td>
                                                <td><input type="text" name="jf" value="<?php echo $r1[3]?>"  id="jf" class="text" style="width:300px;"></td>
                                            </tr>
<?php */?>                                            <tr>
                                                <td>Job Descripation:</td>
                                                <td><textarea rows="3" cols="35" name="jo" value="<?php echo $r1[4]?>" id="ad"></textarea></td>
                                            </tr>
                                            <tr>
                                                <td>Start date</td>
                                            <td><input type="date" name="sd" />
                                                        
                                                    </td>
                                            </tr>
                                            <tr>
                                                <td>Salary:</td>
                                                <td width="69%"><input type="text" name="sl" value="<?php echo $r1[8]?>"  id="sa" class="text" style="width:300px;"></td>
                                            </tr>
                                            <tr>
                                                <td>Contact No:</td>
                                                <td width="69%"><input type="text" name="cn" value="<?php echo $r1[9]?>"  id="cno" class="text" style="width:300px;"></td>
                                            </tr>
                                            <tr>
                                                <td>Email:</td>
                                                <td width="69%"><input type="text" name="em" value="<?php echo $r1[10]?>"  id="mail" class="text" style="width:300px;"></td>
                                            </tr>
                                            <tr>
                                                <td>Location:</td>
                                                <td width="69%" align="left"><select name="lo" value="<?php echo $r1[11]?>" id="loc" style="width:300px;" onChange="occu1()">
                                                        <option selected="selected" value="">Select</option>
                                                        <option value="Navsari">Navsari</option>
                                                        <option value="Ahemdbad">Ahemdbad</option>
                                                        <option value="Valsad">Valsad</option>
                                                        <option value="Vadodara">Vadodara</option>
                                                        <option value="Bharuch">Bharuch</option>
                                                        <option value="Vapi">Vapi</option>
                                                        <option value="Bilimora">Bilimora</option>
                                                        <option value="Bardoli">Bardoli</option>
                                                        <option value="Surat">Surat</option>
                                                        <option value="Others">Others</option>
                                                    </select>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>Last date</td>
                                                <td><input type="date" name="ld" /></td>
                                            </tr>
                                            <tr>
                                            <tr>
                                                <td>Job Type</td>
                                                <td width="69%" align="left"><select name="jt" value="<?php echo $r[15]?>" id="jot" style="width:300px;" onChange="occu1()">
                                                        <option selected="selected" value="">Select</option>
                                                        <option value="Full Time">Full Time</option>
                                                        <option value="Part Time">Part Time </option>
                                                        <option value="Full/Part Time">Full/Part Time</option>
                                                    </select>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                            <td>Qualification</td>
                                            <td>  <select name="q" id="" style="width:300px;">
                                        <option><?php echo $r2[9]?></option>



                                        <option value="10 pass">10 pass</option>      
											
                                        <option value="12 pass">12 pass</option>
                                        <option value="Graduated">graduated</option>
                                        <option value="Post graduated">post graduated</option>
                                        
                                        <option value="Others">Others</option>
                                    </select></td>
                                            </tr>
                                             <tr>
                                            <td>basic</td>
                                            <td>  <select name="basic" id="" style="width:300px;">
                                        <option><?php echo $r2[10]?></option>



                                        <option value="Bca">Bca</option>      




                                        <option value="B.Com">B.Com</option>
                                        <option value="B.Sc">B.Sc</option>
                                        <option value="BBA">BBA</option>
                                        <option value="ITI">ITI</option>
                                        <option value="P.G Diploma">P.G Diploma</option>
                                        <option value="Diploma">Diploma</option>
                                        <option value="BA">BA</option>   
                                        <option value="B.E">B.E</option>
                                        <option value="B.Tech">B.Tech</option>


                                        <option value="Others">Others</option>
                                    </select></td>
                                            </tr>
                                            
                                             <tr>
                                            <td>master</td>
                                            <td>  <select name="master" id="" style="width:300px;">
                                        <option><?php echo $r2[11]?></option>



                                        <option value="Mca">Mca</option>      




                                        <option value="M.Com">M.Com</option>
                                        <option value="M.Sc">M.Sc</option>
                                        <option value="MBA">MBA</option>
                                        <option value="ITI">ITI</option>
                                        <option value=" Diploma">Diploma</option>
                                        <option value="MA">MA</option>   
                                        <option value="M.E">M.E</option>
                                        <option value="M.Tech">M.Tech</option>


                                        <option value="Others">Others</option>
                                    </select></td>
                                            </tr>


                                            <tr>
                                            <td>Experiance</td>
                                            <td><input type="text" name="e"></td>
                                            </tr>
                                            
                                            <tr>
                                            <td>skill</td>
                                            <td><input type="text" name="skill"></td>
                                            </tr>
                                            
                                            <?php
                                                if($_REQUEST['jpid'])
                                                {
                                                ?>
                                                <tr>
                                                    <td></td>
                                                    <td align="center"><input type="submit" name="update" value="Change"onClick="return mesg(this.form);"/>
                                                    <td width="1%">                    
                                                </tr>
                                                <?php 
                                                }
                                                else
                                                {
                                                ?>
                                                <tr>
                                                    <td></td>
                                                    <td align="center"><input type="submit" name="save" value="Save"onClick="return mesg(this.form);"/>
                                                    <td>                    
                                                </tr>
                                                <?php 
                                                }
                                            ?>
                                        </table>
                                </form> </p>
                            </div>
                            <div class="clr"></div>
                        </div>
                        <div class="">


                            <div class="post_content">

                            </div>
                        </div>
                    </div>
                    <div class="sidebar">
                        <div class="gadget">
                            <h2 class="star"><span>Sidebar</span> Menu</h2>
                            <div class="clr"></div>
                            <ul class="sb_menu">
                                <li><a href="Main Page.php">Main Page</a>
                                <li><a href="empreg.php?eid=<?php echo $r['eid']?>">Edit Profile</a></li>
                                <li><a href="employerpro.php?eid=<?php echo $r['eid']?>">View Profile</a></li>
                                <li><a href=" employerchang pass.php?eid=<?php echo $r['eid']?>">Change Password</a></li>
                                <li><a href="sresume.php ?eid=<?php echo $r['eid']?>">Search Resume</a></li> 


                                <li><a href="Job post.php?eid=<?php echo $r['eid']?>">Post Job</a></li> 
                                     
                                <li><a href="feed back.php?eid=<?php echo $r['eid']?>">Feedback</a></li> 
                                <li class="last"><a href="index.php">Logout</a></li> 

                            </ul>
                        </div>
                        <div class="gadget">
                            <div class="clr"></div>

                        </div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
            <div class="fbg">
                <div class="fbg_resize">

                </div>
            </div>
            <div class="footer">
                <div class="footer_resize">
                    <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
                    <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
                    <div style="clear:both;"></div>
                </div>
            </div>
        </div>
        <div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
