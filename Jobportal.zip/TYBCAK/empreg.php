<?php                    
    error_reporting(0);
	ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['eid'];
    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname']; 

    $s="select * from employer where u_name='$uname'";
    $r1=mysql_query($s);
    $r=mysql_fetch_array($r1);


    if(isset($_REQUEST['submit']))
    {
        //echo "hello";
        // $emp_id=$_REQUEST[''];  
        $firstname=$_REQUEST['fname'];
        $lastname=$_REQUEST['lname'];
        $username=$_REQUEST['uname'];
        $password=$_REQUEST['pass'];
        $bussnesstype=$_REQUEST['businesstype'];
        $bussness=$_REQUEST['bname'];
        $emailid=$_REQUEST['email'];
        $mobileno=$_REQUEST['mobile'];  
        $gender=$_REQUEST['name']; 
        

        echo $sql="insert into employer(f_name,l_name,u_name,pass,btype,b_name,e_id,m_no,gender)
        values('$firstname','$lastname','$username','$password','$bussnesstype','$bussness','$emailid','$mobileno','$gender')";

        $t=mysql_query($sql) or die(mysql_error());

        echo "data insert";
        header('location:employee.php');
    }

    if(isset($_REQUEST['eid']))
    {
        $id=$_REQUEST['eid'];
        $sel="select * from employer where eid='$id'";     
        $res=mysql_query($sel);
        $r=mysql_fetch_array($res);
    }
    if(isset($_REQUEST['update']))
    {
        $id=$_REQUEST['eid']; 
        $firstname=$_REQUEST['fname'];
        $lastname=$_REQUEST['lname'];
        $username=$_REQUEST['uname'];
        $password=$_REQUEST['pass'];
        $bussnesstype=$_REQUEST['businesstype'];
        $bussness=$_REQUEST['bname'];
        $emailid=$_REQUEST['email'];
        $mobileno=$_REQUEST['mobile'];  
        $gender=$_REQUEST['name']; 


        $u="update employer set f_name='$firstname',l_name='$lastname',u_name='$username',pass='$password',b_name='$bussness',e_id='$emailid',m_no='$mobileno',gender='$gender' where eid='$id'";
        mysql_query($u);
        header('location:employee.php');
    }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>empreg</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
 <script type="text/javascript">

        function mesg(form)
        {     

            var fname=document.getElementById('fname');
            var lname=document.getElementById('lname');     
            var uname=document.getElementById('uname');       
            var pass=document.getElementById('pass');
			var bussinesstype=document.getElementById('name1');
            var bname=document.getElementById('bname');
            var email=document.getElementById('email');
            var p=document.getElementById('p');
            var name=document.getElementById('name');      



            var alpha = /^[a-zA-Z' _]+$/;
            var pa = /^[a-zA-Z0-9'_]+$/;
            var em = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;   
            var haschecked=false;
            var ph =/^\{10}$/;  
            var tel_no=/^[\d]{6,10}$/; 

            if(fname.value == '')
                {
                alert("Please fillup the firstname");
                fname.focus();
                return false;
            } 

            else if(!alpha.test(fname.value))
                {

                alert("please enter first name is Charcter values");
                fname.focus();
                fname.value='';
                return false;
            } 




            else if(lname.value == '')
                {
                alert("Please fillup the lastname");
                lname.focus();
                return false;
            } 

            else if(!alpha.test(lname.value))
                {

                alert("please enter last name is Charcter values");
                lname.focus();
                lname.value='';
                return false;
            } 


            if(uname.value == '')
                {
                alert("Please fillup the username");
                uname.focus();
                return false;
            } 

            else if(!alpha.test(fname.value))
                {

                alert("please enter  username is Charcter values");
                uname.focus();
                uname.value='';
                return false;
            } 
				

            else if(pass.value=='')
                {
                alert("plese fillup the password");
                pass.focus();
                return false;
            }
            else if(!pa.test(pass.value))
                {

                alert("please enter Charcter values");
                pass.focus();
                pass.value='';
                return false;
            }
			if(bussinesstype.value == '')
                {
                alert("Please fillup the bussinesstype");
                name1.focus();
                return false;
            } 

            else if(!alpha.test(name1.value))
                {

                alert("please enter  bussinesstype  Character values");
                name1.focus();
                name1.value='';
                return false;
            }
						
            if(bname.value == '')
                {
                alert("Please fillup the bussinessname");
                bname.focus();
                return false;
            } 

            else if(!alpha.test(bname.value))
                {

                alert("please enter bussiness name is Character values");
                bname.focus();
                bname.value='';
                return false;
            } 


            else if(email.value=='')
                {

                alert("Please fill the email");
                email.focus();
                return false;

            }
            else if(!em.test(email.value))
                {
                alert("Please enter valide Emailid");
                email.value= '';
                email.focus();
                return false;

            }




            if(p.value=='')
                {

                alert("Please fill the Mobile NO");
                p.focus();
                return false;

            }
            if(!tel_no.test(p.value))
                {
                alert("Invalid Mobile Number..");
                return false;
            }   

            if
            (name.value=='')      
                {
                alert("Please fill the gender");
                name.focus();
                return false;

            }

            else
                {
                return true;
            }
        }                    

    </script>     
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
               <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employee</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
?>
        </ul>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <!--<span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />-->
        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
       <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   
        <!--<h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-style:inherit;color:#00F";>Career.Com</span> <small>Company Slogan Here</small></a></h1>
      --></div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider">
         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a></div>
        </div>
                       
         </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="">
          <!--<h2><span>Excellent Solution</span> For Your Business</h2>
          <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>-->
          <div class="clr"></div>
          <div class="img">
          <!--<img src="images/img1.jpg" width="640" height="188" alt="" class="fl" />--></div>
          <div class="post_content">
            <p> <form name=good method="post">
              <table style="margin-left:380;"border="2"cellpadding="10" cellspacing="10" bordercolorlight="#000000"width="400px">

                <tr>
                        <?php
                            if($_REQUEST[eid])
                            {
                            ?>
                            <td align="center" colspan="2"><font size="6" face="Times New Roman, Times, serif" color="#2695C3"><b>Edit Your Profile</b></font></td>
                            <?php 
                            } 
                            else
                            {
                            ?>
                            <td align="center" colspan="2"><font size="5" face="Times New Roman, Times, serif" color="#0000FF"><b>Employer Registration</b></font></td>
                            <?php 
                            }
                        ?>

                    </tr>
                    <tr>
                        <td style="color:#006">First Name:</td>
                        <td><input type="text" name="fname"  id="fname" value="<?php echo $r['f_name']?>"></td>
                    </tr>

                    <tr>
                        <td style="color:#006">Last Name:</td>
                        <td><input type="text" name="lname" id="lname" value="<?php echo $r['l_name']?>"/></td>
                    </tr>

                    <tr>
                        <td style="color:#006">User Name:</td>

                        <td><input type="text" name="uname"  id="uname" value="<?php echo $r['u_name']?>"></td>
                    </tr>

                    <tr>
                        <td style="color:#006">Password:</td>
                        <td><input type="password" name="pass" id="pass" value="<?php echo $r['pass']?>"/></td>
                    </tr>
                    <tr>
                        <td style="color:#006">Busssiness type:</td>
                        <td><input type="radio" name="businesstype" id="name1" value="Goverment Institution" />Goverment Institution<br/>
                        <input type="radio" name="businesstype" id="name1"  value="Individual" />Individual <br/>

                        <input type="radio" name="businesstype" id="name1" value="Private Organization" />Private Organization<br/>
                        <input type="radio" name="businesstype" id="name1"  value="Recruitment/Consolting" />Recruitment/Consolting <br/>

                    </tr>

                    <tr>
                        <td style="color:#006">Bussiness Name:</td>
                        <td><input type="text" name="bname" id="bname" value="<?php echo $r['b_name']?>"/><br>(Enter School Or Company Name)</td>
                    </tr>

                    <tr>
                        <td style="color:#006">Email Id:</td>
                        <td><input type="text" name="email" id="email" value="<?php echo $r['e_id']?>"/></td>
                    </tr>

                    <tr>
                        <td style="color:#006">Mobile No:</td>
                        <td><input type="text" name="mobile" id="p" value="<?php echo $r['m_no']?>" /></td>
                    </tr>

                    <tr>
                        <td style="color:#006">Gender:</td>
                        <?php
                            if($r['gender']=="male")
                            {
                            ?>
                            <td><input type="radio" name="name" id="name" value="male" checked="checked">Male 
                                <input type="radio" name="name" id="name" value="female">Female 
                            </td>
                            <?php 
                            }
                            else if($r['gender']=="female")
                                {
                                ?>
                                <td><input type="radio" name="name" id="name" value="male">Male 
                                    <input type="radio" name="name" id="name" value="female" checked="checked">Female 
                                </td>
                                <?php 
                                }
                                else
                                {
                                ?>
                                <td><input type="radio" name="name" id="name" value="male">Male 
                                    <input type="radio" name="name" id="name" value="female">Female 
                                </td>
                                <?php 
                            }
                        ?>
                    </tr>

                    


                    <tr>
                        <?php
                            if(isset($_REQUEST['eid']))
                            {
                            ?>
                            <td>
                            </td>
                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="update" value="Update" onClick="return mesg(this.form);"/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" name="RESET" value="Reset" />
                            </td>
                            <?php 
                            }
                            else
                            {
                            ?>
                            <td>
                            </td>
                            <td>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Sumbit" onClick="return mesg(this.form);"/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" name="RESET" value="Reset" />
                            </td>
                            <?php 
                            }
                        ?>  
                    </tr>

                    </table>



                </form></p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
           <ul class="sb_menu">
                    <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employer.php?uname=<?php echo $uname?>"><span>Employer</span></a></li>
          <li><a href="jobseeker.php?uname=<?php echo $uname?>"><span>Jobseeker</span></a></li>
          <li><a href="About.php?uname=<?php echo $uname?>"><span>About</span></a></li>
          <li><a href="contact.php?uname=<?php echo $uname?>"><span>Contact Us</span></a></li>
          </ul> 
                      
            </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
