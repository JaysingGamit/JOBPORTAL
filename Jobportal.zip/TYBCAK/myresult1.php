<?php
	error_reporting(0);
    ob_start();
    session_start();        
    include('conn.php');     

 if(isset($_REQUEST['h']))
{
    $a=$_REQUEST['h'];
    $sel="select * from jobpost where j_ti LIKE '$a%'";
    $r=mysql_query($sel);
    while($b=mysql_fetch_array($r))
    {
        if(mysql_num_rows($r)>0)
        {
            ?>
<div style="border:3; width:2;background-color:white; height: 50px; width: 70px; margin-left:-300px; margin-top: 20px;font-size: 15px" > <p><a href="search_result1.php?j_ti=<?php echo $b['j_ti'];?>"><?php echo $b['j_ti'];?></a></p></div>
            <?php 
        }
    }
}
?>
