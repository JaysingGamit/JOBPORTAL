
<html>
<head>
	<title> Look Me! </title>

        
	
	<script type="text/javascript" src="Registration_validation.js"> </script>
</head>
<script>
	function time_get()
	{
		d = new Date();
		mon = d.getMonth()+1;
		time = d.getDate()+"-"+mon+"-"+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes();
		Reg.fb_join_time.value=time;
	}
</script>
<body>
	 
	
	<!-- Look Me! left part -->
	
		<!--Left part-->
		<!--Mobile Image--> 	
	<div style="position:absolute; left:5%; top:35%;"> <img src="fb_files/fb_image_file/look_me_map.PNG" width="700" height="275"> </div>
    <div style="position:absolute; left:7%; top:24%; color:rgb(166,122,218); font-size:28px;"> <font face="myFbFont"> Look Me! helps you connect and share with </font> </div>
    <div style="position:absolute; left:7%; top:30%; color:rgb(166,122,218); font-size:28px;"> <font face="myFbFont"> the people in your life. </font></div>
	
	<div style="position:absolute;left:58%; top:14.5%; color:#000066; font-size:25"> <h5> Sign Up </h5> </div>
		<div style="position:absolute;left:58%; top:24.6%; color:#000000;">  It's free and always will be.  </div>
		<div style="position:absolute;left:57.3%; top:29.1%; height:1; width:385; background-color:#CCCCCC;"> </div>
	
	<!-- Registration -->
<!--	<form  method="post" onSubmit="return check();" name="Reg">
		
        
		<div style="position:absolute;left:59.4%; top:34%; font-size:16px; color:#000000">  First Name: </div>
		<div style="position:absolute;left:65.2%;   top:32.8%; "> <input type="text" name="first_name" class="inputbox" maxlength="10" required/> </div>
		<div style="position:absolute;left:59.4%; top:41%; font-size:16px; color:#000000">  Last Name: </div>
		<div style="position:absolute;left:65.2%;  top:39.8%;  "> <input type="text" name="last_name"  size="25" class="inputbox" maxlength="10"  required=""/> </div>
		<div style="position:absolute;left:59.2%; top:48%; font-size:16px; color:#000000">  Your Email:  </div>
		<div style="position:absolute;left:65.2%;  top:46.8%; "> <input type="text" name="email"  size="25" class="inputbox" required/> </div>
		<div style="position:absolute;left:57.4%; top:55%; font-size:16px; color:#000000">  Re-enter Email:  </div>  
		<div style="position:absolute;left:65.2%; top:53.8%; "> <input type="text" name="remail"  size="25" class="inputbox" required/> </div>
		<div style="position:absolute;left:57.4%; top:62%; font-size:16px; color:#000000"> New Password:  </div>
		<div style="position:absolute;left:65.2%; top:60.8%; "> <input type="password" name="password" size="25" class="inputbox" required/> </div>
		<div style="position:absolute;left:62.2%; top:68.5%; font-size:16px; color:#000000"> I am:  </div>
		<div style="position:absolute;left:65.2% ;top:67.8%;">		  
		<select name="sex" style="width:120;height:35;font-size:18px;padding:3;">
			<option value="Select Sex:"> Select Sex: </option>
			<option value="Female"> Female </option>
			<option value="Male"> Male </option>
		</select>
		</div>
		
<div style="position:absolute;left:60.28%; top:74.8%; font-size:16px; color:#000000">  Birthday:  </div>

	
	<div style="position:absolute;left:65.2%; top:74%;">
	<select name="month" style="width:80;font-size:18px;height:32;padding:3;">
	<option value="Month:"> Month: </option>
	
	<script type="text/javascript">
	
		var m=new Array("","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
		for(i=1;i<=m.length-1;i++)
		{
			document.write("<option value='"+i+"'>" + m[i] + "</option>");
		}	
	</script>
	
	</select>
	</div>



	<div style="position:absolute; left:72%; top:74%;">
	<select name="day" style="width:63;font-size:18px;height:32;padding:3;">
	<option value="Day:"> Day: </option>
	
	<script type="text/javascript">
	
		for(i=1;i<=31;i++)
		{
			document.write("<option value='"+i+"'>" + i + "</option>");
		}
		
	</script>
	
	</select>
	</div>	

	<div style='position:absolute;left:77.5%;top:74%;'>
	<select name="year" style="width:70; font-size:18px; height:32; padding:3;">
	<option value="Year:"> Year: </option>
	
	<script type="text/javascript">
	
		for(i=1996;i>=1960;i--)
		{
			document.write("<option value='"+i+"'>" + i + "</option>");
		}
	
	</script>
	
	</select>
	</div>		
		<input type="hidden" name="fb_join_time">
		<div style="position:absolute;left:65.2%; top:82%; ">  <input type="submit" name="signup" value="Sign Up" id="sign_button" / onClick="time_get()"> </div>
		</form> -->
		<div style=" right:20%; top:33%; position:absolute; width:300px;">
    	<center>	
        	<div id="p_Bar" style=""></div>
            <div id="pass" ></div>
            <div id="c_name" style="position:absolute;margin-left:300px; margin-top:13px"  ></div>
            <div id="c_lname" style="position:absolute; margin-top:55px; margin-left:300px;"   ></div>
            <div id="c_p" style="position:absolute;margin-top:240px; margin-left:300px; width:200px" ></div>
            <div id="eml" style="position:absolute;margin-left:300px; margin-top:100px; width:200px"  ></div>
            <div id="dt" style="position:absolute;margin-left:320px; margin-top:160px;" ></div>
       	
    	<form method="post" name="Reg" >
    		<table align="center" cellpadding="5px" width="500px" border="0">
        		<tr>
            		<td>
	                	<input type="text" placeholder="First Name :" required  autofocus="autofocus"  class="text"  name="first_name" onBlur="f_er()"  />
  	                </td>
  	             </tr>
   	            <tr>
   	          		<td>
                		<input type="text" placeholder="Last Name :" required class="text"  name="last_name" onBlur="l_er()"  />
                	 </td>
          		</tr>
                <tr>
             		<td>
						<input type="Email" required placeholder="<?php if(isset($_REQUEST['er'])){ echo $_REQUEST['er']; }else{echo 'Email Address :';} ?>"  name="email" class="email_text" onBlur="e_chk();" />
              		</td>
                    
                </tr>
            	<tr>
             		<td>
                		<b>Date Of Birth : </b><br>
               	    	<input type="text" required name="day" placeholder="Day" maxlength="2" class="text" style="width:80px;" onBlur="Reg.month.focus();"/>
                        <input type="text" required name="month" placeholder="Month" maxlength="2" class="text" style="width:80px;" onBlur="Reg.year.focus();"  />
                        <input type="text" required name="year" placeholder="Year" maxlength="4" class="text" style="width:130px;" onBlur="d_chk();" />
              		</td>
                    <td>
                    </td>
                </tr>
                 <tr>
             		<td>
						<input type="password" placeholder="Password :" required   oninput="p_chk();" name="password"  class="" />
              		</td>
                    
                </tr>    
                <tr>
             		<td>
						<input type="Password" placeholder="Confirm Password :" required name="cpass" oninput="conf_pass()"   />
              		</td>
                </tr>  
                 <tr>
             		<td>
               		 	<b>Gender :</b>
               		
               		 	 <input type="radio" checked="checked"   name="g" value="Male" />Male&nbsp; <input type="radio" name="g"  value="Female" />Female
                	</td>
                    
                </tr>
                
                              
           </table><br />
			<input type="hidden" name="fb_join_time">
		  <div> 
           	<input type="submit" style="height:40; width:200"  name="signup" value="Sign Up" class="button" onClick="conf_pass(); time_get();"   />
        </div>
       </form>
       
       </fieldset>
       </center>
    </div>	

		<div style="position:absolute;left:57.3%; top:90%; height:1; width:385; background-color:#CCCCCC; "> </div> 
        
 
				
</body>
</html>