
function f_er(){
	
	var n = Reg.first_name.value;
	var flg=false;
	var tmp = "";
	if(n.length !=0 ){
	
		for(i=0;i<n.length;i++){
			tmp = n.substr(i,1);
			if ( ( tmp >= "a" && tmp <= "z" ) || (tmp >= "A" && tmp <= "Z")){
						
			}
			else {
					flg=true;
					break;	
			}
			
		}
		if(flg){
			document.getElementById("c_name").innerHTML = "<img src='s_error.png' title='Name Cannot Contain Digits' height=18px style='box-shadow:1px 1px 10px #000; border-radius:10px' />";
			Reg.first_name.focus();
		}
		else
		{
			document.getElementById("c_name").innerHTML = "";
			
			
		}
	}
	else
	{	
		document.getElementById("c_name").innerHTML = "<img src='s_error.png' title='Cant' height=18px style='box-shadow:1px 1px 10px #000; border-radius:10px' />";		
		Reg.first_name.focus()
	}
}
function l_er(){
	
	var n = Reg.last_name.value;
	var flg=false;
	var tmp = "";
	
if(n.length !=0 ){
		for(i=0;i<n.length;i++){
			tmp = n.substr(i,1);
			if ( ( tmp >= "a" && tmp <= "z" ) || (tmp >= "A" && tmp <= "Z")){
						
			}
			else {
					flg=true;
					break;	
			}
			
		}
		if(flg){
			document.getElementById("c_lname").innerHTML = "<img src='s_error.png' height=18px style='box-shadow:1px 1px 10px #000; border-radius:10px' />";
			Reg.last_name.focus();
		}
		else
		{
			document.getElementById("c_lname").innerHTML = "";
			
		}
	}
	else
	{	
		document.getElementById("c_lname").innerHTML = "<img src='s_error.png' height=18px style='box-shadow:1px 1px 10px #000; border-radius:10px' />";		
		Reg.last_name.focus();
	}
}
function p_chk(){
	var n= Reg.password.value;
	if( n.length != 0){	
	var w = 0;
	var flg;
	var f = Reg.first_name.value;
	var l = Reg.last_name.value;
	var e = Reg.email.value;
	var d1 = Reg.day.value+Reg.month.value+Reg.year.value;
	var d2 = Reg.year.value+Reg.month.value+Reg.day.value;
	var d3 = Reg.month.value+Reg.day.value+Reg.year.value;
	if(f==n || l==n || f+l==n || l+f==n ){
		document.getElementById("p_Bar").innerHTML='';
		document.getElementById("pass").innerHTML="<font color=red size=4 >do not use youre name</font>";
		return;
	}
	if(e==n ){
		document.getElementById("p_Bar").innerHTML='';
		document.getElementById("pass").innerHTML="<font color=red size=4 >do not use youre email</font>";
		return;
	}
	if(d1==n|| d2==n || d3==n ){
		document.getElementById("p_Bar").innerHTML='';
		document.getElementById("pass").innerHTML="<font color=red size=4 >do not use youre DOB</font>";
		return;
	}
		
		for(i=0;i<n.length;i++){
			tmp=n.substr(i,1);
			
			if( n.length <=5){
				if( ( tmp.match(/[a-z]/) || tmp.match(/[A-Z]/) )){
					document.getElementById("p_Bar").innerHTML="<hr color=red size=3px width=50px >";
					document.getElementById("pass").innerHTML="<font color=red size=4 >Weak</font>";	
				}
				else 	if(  tmp.match(/[0-9]/) ){
					document.getElementById("p_Bar").innerHTML="<hr color=orange size=3px width=70px >"	;
					document.getElementById("pass").innerHTML="<font color=orange size=4 >Normal</font>";		
				}
				else 	if( tmp.match(/[!,@,#,$,%,^,&,*,(,),_,<,>,]/)  ){
					document.getElementById("p_Bar").innerHTML="<hr color=green size=3px width=90px >"	;
					document.getElementById("pass").innerHTML="<font color=green size=4 >Strong</font>"	
				}
				else
				{
					document.getElementById("p_Bar").innerHTML="<hr color=red size=3px width=50px >";
					document.getElementById("pass").innerHTML="<font color=red size=4 >Weak</font>";						
				}
			}
			else if( n.length <= 8 ){
				if( ( tmp.match(/[a-z]/) || tmp.match(/[A-Z]/) )){
					document.getElementById("p_Bar").innerHTML="<hr color=orange size=3px width=70px >"	;
					document.getElementById("pass").innerHTML="<font color=orange size=4px >Normal</font>";		
				}
				if(  tmp.match(/[0-9]/) ){
					document.getElementById("p_Bar").innerHTML="<hr color=orange size=3px width=70px >"	;
					document.getElementById("pass").innerHTML="<font color=orange size=4px >Normal</font>";		
				}
				if( tmp.match(/[!,@,#,$,%,^,&,*,(,),_,<,>,]/) ){
					document.getElementById("p_Bar").innerHTML="<hr color=green size=3px width=90px >"	;
					document.getElementById("pass").innerHTML="<font color=green size=4px >Strong</font>"	
				}
					
			}
			else if( n.length <= 12){
				if( ( tmp.match(/[a-z]/) || tmp.match(/[A-Z]/) )){
					document.getElementById("p_Bar").innerHTML="<hr color=orange size=3px width=70px >"	;
					document.getElementById("pass").innerHTML="<font color=orange size=4px >Normal</font>";		
				}
				if(  tmp.match(/[0-9]/) ){
					document.getElementById("p_Bar").innerHTML="<hr color=orange size=3px width=70px >"	;
					document.getElementById("pass").innerHTML="<font color=orange size=4px >Normal</font>";		
				}
				if( tmp.match(/[!,@,#,$,%,^,&,*,(,),_,<,>,]/) ){
					document.getElementById("p_Bar").innerHTML="<hr color=green size=3px width=90px >"	;
					document.getElementById("pass").innerHTML="<font color=green size=4px >Strong</font>"	
				}
					
			}
			else
			{
				document.getElementById("p_Bar").innerHTML="<hr color=green size=3px width=90px >"	;
				document.getElementById("pass").innerHTML="<font color=green size=4px >Strong</font>"	
				
			}
			
			
	
		}
	}
	else
	{
			document.getElementById("p_Bar").innerHTML="";
			document.getElementById("pass").innerHTML="";
	}
	

}
function conf_pass(){
	var p = Reg.password.value;
	var c = Reg.cpass.value;
	if(p != "" && c !="" ){
		if ( c == p ){
			document.getElementById("c_p").innerHTML = "<font color=green size=3 style='text-shadow:0px 0px 10px #FFFFFF'	 ><b> Password Match</b></font>";
			
		}
		else
		{
			document.getElementById("c_p").innerHTML = "<font color=red size=3 ><b> Password doesn't Match</b></font>";
			Reg.cpass.focus();
			Reg.action="new reg.php";
		}
	}
	else
	{
			document.getElementById("c_p").innerHTML = "<font color=red size=3 ><b> Can't Left empty</b></font>";
			Reg.action="new reg.php";
	}
}
function e_chk(){
	var email = Reg.email.value;
	//alert(email);
	var atpos=email.indexOf("@");
	var dotpos=email.lastIndexOf(".");
	if (email == ''){
		document.getElementById("eml").innerHTML = "<img src='s_error.png' height=18px style='float:left; box-shadow:1px 1px 10px #000; border-radius:10px' />";
		Reg.email.focus();
	}
    else if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length){
		document.getElementById("eml").innerHTML = "<font color=green size=3 style='text-shadow:0px 0px 10px #FFFFFF'	 ><b>Invalid Email id</b></font>";
       Reg.email.focus();
    
 }
 else
 {
	document.getElementById("eml").innerHTML = '';
 }
}
function d_chk(){
	var d=Reg.day.value+'-'+Reg.month.value+'-'+Reg.year.value;
	var flg=0;
	//alert(d);
	var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;  
  // Match the date format through regular expression  
	if(d.match(dateformat)){  
		 
		//Test which seperator is used '/' or '-'  
		var opera1 = d.split('/');  
		var opera2 = d.split('-');  
		lopera1 = opera1.length;  
		lopera2 = opera2.length;  
		// Extract the string into month, date and year  
		if (lopera1>1){  
			var pdate = d.split('/');  
		}  
		else if (lopera2>1){  
			var pdate = d.split('-');  
		}  
		var mm = parseInt(pdate[1]);  
		var dd = parseInt(pdate[0]);  
		var yy = parseInt(pdate[2]);  
		if(mm>12){
			document.getElementById("dt").innerHTML = 'month is not valid';
  			Reg.month.focus();
			return; 
		}
		// Create list of days of a month [assume there is no leap year by default]  
		var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];  
		if (mm==1 || mm>2){  
			if (dd>ListofDays[mm-1]){  
				document.getElementById("dt").innerHTML = 'Day is not valid';
  				Reg.day.focus();
				return;  
			}  
		}  
		if (mm==2){  
			var lyear = false;  
			if ( (!(yy % 4) && yy % 100) || !(yy % 400)){  
				lyear = true;  
			}  
			if ((lyear==false) && (dd>=29)){  
				document.getElementById("dt").innerHTML = 'Day is not valid';
  				Reg.day.focus();
				return;  
			}  
			if ((lyear==true) && (dd>29)){  
				document.getElementById("dt").innerHTML = 'Day is not valid';
  				Reg.day.focus();
				return;
			}  
		}  
	}  
	else{  
		document.getElementById("dt").innerHTML = 'Invalid';
  		Reg.day.focus(); 
		return;
	}
	document.getElementById("dt").innerHTML = '';
}