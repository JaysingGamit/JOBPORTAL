<?php
    error_reporting(0);
	ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['j_id'];
    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname']; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="gu">
<head>
<title>home</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<link rel="stylesheet" type="text/css" href="anylinkmenu.css" />
<link rel="stylesheet" type="text/css" href="style.css" />
<script type="text/javascript" src="menucontents.js"></script>

<script type="text/javascript" src="anylinkmenu.js">

/***********************************************
* AnyLink JS Drop Down Menu v2.0- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Project Page at http://www.dynamicdrive.com/dynamicindex1/dropmenuindex.htm for full source code
***********************************************/

</script>

<script type="text/javascript">

//anylinkmenu.init("menu_anchors_class") //Pass in the CSS class of anchor links (that contain a sub menu)
anylinkmenu.init("menuanchorclass")

</script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
            <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>પ્રથમપાનું</span></a></li>
         
          <li><a href="About.php"><span>વિશેષ માહિતી</span></a></li>
          <li><a href="contact.php"><span>સંપર્ક</span></a></li>
     <li><a href="jobs.php" class="menuanchorclass" rel="anylinkmenu4" style="font-style:inherit;color:#FFF">નોકરી</a></li>

        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>પ્રથમપાનું</span></a></li>
         <!-- <li><a href="employee.php"><span>Employee</span></a></li>-->
          <li><a href="jobseeker.php"><span>રોજગાર શોધક</span></a></li>
          <li><a href="About.php"><span>માહિતી</span></a></li>
          <li><a href="contact.php"><span>સંપર્ક</span></a></li>
        </ul>
        <?php 
    }
?>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <!--<span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
-->        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
       <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   
       <!-- <h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-size:40px;color:#00C;">Career.Com</span> <small>Company Slogan Here</small></a></h1>
       <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   --></div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider">
         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a>
                       
         </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="">
          <!--<h2><span>Excellent Solution</span> For Your Business</h2>
          <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>-->
          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="640" height="188" alt="" class="fl" /></div>
          <div class="post_content">
            <p>
                                           <fieldset class="div_midal">
            <div>
            <br>
            <p>&nbsp;&nbsp;<h1 align="center" style="font-size:x-large; color:#2695C3;margin-left:20px; margin-top:-50px;">Welcome <?php echo $uname?></h1></font></p>
        
            <span>
            <p align="center"></p><h3><font color="#2695C3" size="4" face="Times New Roman, Times, serif">&nbsp;&nbsp;A Tip From Us:</font></h3><b> Want to increase your chances of finding a job? Then go to <a href="Post Resume.php">Submit your Resume</a> now! Only fill in the fields that you want, and there is an option for keeping your details anonymous too! Once filled in, employers will be able to search for you. Hundreds of subscribed employers will also receive an alert by email, informing them of you.</b><p></p><p></p> </span>
            <br>
           
        </fieldset>
            </p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
                    <li><a href="Home.php">Main Page</a></li>
                    <li><a href="jobseeker_home.php?uname=<?php echo $uname?>">Account Detail</a></li>
                    <li><a href="jseeker_pass_change.php?uname=<?php echo $uname?>">Change Password </a></li>
                    <li><a href="Post Resume.php?uname=<?php echo $uname?>">Resume</a></li>
                    <!--<li><a href="eresume.php">Show Resume</li>
-->                   <!-- <li><a href="search job 1.php">Job Search</a></li>-->
                    <li><a href="feed back1.php?uname=<?php echo $uname?>">Feed Back </a></li>
                    <li><a href="Contact.php?uname=<?php echo $uname?>">Contact Us</a></li>
                    <li class="last"><a href="logout.php">Logout</a></li> 
          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
