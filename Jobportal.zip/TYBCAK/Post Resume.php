<?php 
	error_reporting(0);                   
    ob_start();
    session_start();        
    include('conn.php');     
    $id=$_REQUEST['j_id'];
    //$uname=$_REQUEST['uname'];
    $uname=$_SESSION['uname']; 



    if(isset($_REQUEST['submit']))
    {
        //echo "hello";
        // $rid=$_REQUEST[''];
        $email=$_REQUEST['email'];
        $uname=$_REQUEST['uname'];
        $nationality=$_REQUEST['nation'];
        $dateofbirth=$_REQUEST['date'];
        $gender=$_REQUEST['gen'];
        $currentcountry=$_REQUEST['cbocountry'];
        $currentcity=$_REQUEST['city'];
        $contactnumber=$_REQUEST['mobile'];
        $bachelordegree=$_REQUEST['degree'];
        $institution=$_REQUEST['institute'];
        $masterdegree=$_REQUEST['mdegree'];
        $masterinstitution=$_REQUEST['minstitute'];
        $yearofgraduation=$_REQUEST['gradyear'];
        $totalexperience=$_REQUEST['exp'];
        $annualsalary=$_REQUEST['as'];
        $industry=$_REQUEST['industry'];
        $functionalarea=$_REQUEST['funcarea'];
        $resumeheading=$_REQUEST['resumehead'];
        $name=$_FILES['file']['name'];
        $tmp=$_FILES['file']['tmp_name'];
        $path="Resume/".$name;

        move_uploaded_file($tmp,$path); 



        $sql="insert into resume(email,uname,nationality,dob,gender,c_country,c_city,c_no,degree,institution,mdegree,minstitution,yog,t_experience,a_salary,industry,f_area,r_heading,resume)
        values ('$email','$uname','$nationality','$dateofbirth','$gender','$currentcountry','$currentcity','$contactnumber','$bachelordegree','$institution','$masterdegree','$masterinstitution','$yearofgraduation','$totalexperience','$annualsalary','$industry','$functionalarea','$resumeheading','$path')"; 
        mysql_query($sql) or die("Could not insert");

        echo "data insert";
        header('location:home.php');
    }

    if(isset($_REQUEST['rid']))
    {
        $id=$_REQUEST['rid'];
        $sel="select * from resume where rid='$id'";     
        $res=mysql_query($sel);
        $r2=mysql_fetch_array($res);
    }
    if(isset($_REQUEST['update']))
    {
        $id=$_REQUEST['rid'];         
        $email=$_REQUEST['email'];
        $name=$_REQUEST['name'];
        $nationality=$_REQUEST['nation'];
        $dateofbirth=$_REQUEST['date'];
        $gender=$_REQUEST['gen'];
        $currentcountry=$_REQUEST['cbocuntry'];
        $currentcity=$_REQUEST['city'];
        $contactnumber=$_REQUEST['mobile'];
        $bachelordegree=$_REQUEST['degree'];
        $institution=$_REQUEST['institute'];
        $masterdegree=$_REQUEST['mdegree'];
        $masterinstitution=$_REQUEST['minstitute'];
        $yearofgraduation=$_REQUEST['gradyear'];
        $totalexperience=$_REQUEST['exp'];
        $annualsalary=$_REQUEST['as'];
        $industry=$_REQUEST['industry'];
        $functionalarea=$_REQUEST['funcarea'];
        $resumeheading=$_REQUEST['resumehead'];
        $name=$_FILES['file']['name'];
        $tmp=$_FILES['file']['tmp_name'];
        $path="Resume/".$name;


        $u="update resume set email='$email',uname='$name',nationality='$nationality',dob='$dateofbirth',
        gender='$gender',c_country='$currentcountry',c_city='$currentcity',c_no='$contactnumber',degree='$bachelordegree',
        institution='$institution',mdegree='$masterdegree',minstitution='$masterinstitution',yog='$yearofgraduation',t_experience='$totalexperience',a_salary='$annualsalary'
        ,industry='$industry',f_area='$functionalarea',r_heading='$resumeheading'where rid='$id'";

        mysql_query($u);
        header("location:home.php");
    }
	 if(!$_SESSION['uname'])
{
	header("location:jobseeker.php");
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>postResume</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
      <script type="text/javascript">

       function mesg(form)
        {     

            var email=document.getElementById('email');
            var name=document.getElementById('name');     
            var national=document.getElementById('nation');       
            var dob=document.getElementById('dob');
            var gen=document.getElementById('gen');
            var cbocountry=document.getElementById('cbocountry');
            var city=document.getElementById('city');
            var mobile=document.getElementById('mobile');
            var degree=document.getElementById('degree');
            var institute=document.getElementById('institute');
            var mdegree=document.getElementById('mdegree');
            var minstitute=document.getElementById('minstitute');
            var gradyear=document.getElementById('gradyear');
            var month=document.getElementById('month');
            var year=document.getElementById('year');
            var expmonth=document.getElementById('expmonth');
            var as=document.getElementById('as');
            var ind=document.getElementById('ind');
            var funcarea=document.getElementById('funcarea');
            var rh=document.getElementById('rh');

            var alpha = /^[a-zA-Z' _]+$/; 
            var em = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;   

            if(email.value=='')
                {

                alert("Please fill the email");
                email.focus();
                return false;

            }
            else if(!em.test(email.value))
                {
                alert("Please enter valid Emailid");
                email.value= '';
                email.focus();
                return false;

            }

            if(name.value == '')
                {
                alert("Please fill up the Name");
                name.focus();
                return false;
            } 

            else if(!alpha.test(name.value))
                {
                alert("Please Enter Charcter Value");
                name.value= '';
                name.focus();
                return false;

            }

            if(nation.value == '')
                {
                alert("Please fill up the National");
                nation.focus();
                return false;
            } 

            if(dob.value == '')
                {
                alert("Please fill up the Date Of Birth");
                dob.focus();
                return false;
            } 

            if((form.gen[0].checked==false) &&(form.gen[1].checked==false))
                {

                alert("Please fill the gender");
                gen.focus();
                return false;

            }   



            if(cbocountry.value == '')
                {
                alert("Please fill up the Current Country");
                cbocountry.focus();
                return false;
            }

            if(city.value == '')
                {
                alert("Please fill up the Current City");
                city.focus();
                return false;
            }
            else if(!alpha.test(city.value))
                {
                alert("Please Enter Charcter Value");
                city.value= '';
                city.focus();
                return false;

            }


            if(mobile.value == '')
                {
                alert("Please fill up the Contact Number");
                mobile.focus();
                return false;
            }

            if(degree.value == '')
                {
                alert("Please fill up the degree");
                degree.focus();
                return false;
            }

            if(institute.value == '')
                {
                alert("Please fill up the Institute");
                institute.focus();
                return false;
            }

            else if(!alpha.test(institute.value))
                {
                alert("Please Enter Charcter Value");
                institute.value= '';
                institute.focus();
                return false;

            }

            if(mdegree.value == '')
                {
                alert("Please fill up the Master Degree");
                mdegree.focus();
                return false;
            }


            if(minstitute.value == '')
                {
                alert("Please fill up the Master Institute");
                minstitute.focus();
                return false;
            }

            else if(!alpha.test(minstitute.value))
                {
                alert("Please Enter Charcter Value");
                minstitute.value= '';
                minstitute.focus();
                return false;

            }

            if(gradyear.value == '')
                {
                alert("Please fill up the Year Of Graduation");
                gradyear.focus();
                return false;
            }

            if(month.value == '')
                {
                alert("Please fill up the Month");
                month.focus();
                return false;
            }
            if(year.value == '')
                {
                alert("Please fill up the Year");
                year.focus();
                return false;
            }

            if(as.value == '')
                {
                alert("Please fill up the Aunnal Salary");
                as.focus();
                return false;
            }

            if(ind.value == '')
                {
                alert("Please fill up the Industry");
                ind.focus();
                return false;
            }

            if(funcarea.value == '')
                {
                alert("Please fill up the Functional Area");
                funcarea.focus();
                return false;
            }

            if(rh.value == '')
                {
                alert("Please fill up the Resume Headline");
                rh.focus();
                return false;
            }

            else if(!alpha.test(rh.value))
                {
                alert("Please Enter Charcter Value");
                rh.value= '';
                rh.focus();
                return false;

            }

            else
                {
                return true;
            }


        }
                         
       var myfile="";
        $('#resume_link').click(function() {
            $('#resume').trigger('click');
            myfile=$('#resume').val();
            var ext = myfile.split('.').pop();
            //var extension = myfile.substr( (myfile.lastIndexOf('.') +1) );

            if(ext=="pdf" || ext=="docx" || ext=="doc"){
                alert(ext);
            }
            else{
                alert(ext);
            }
         })

    </script> 
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
             <?php
    if($_SESSION['uname'])
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
         
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
    else
    {
        ?>
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employer</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
        <?php 
    }
?>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <!--<span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />-->
        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
       <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>
                   
        <!--<h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-style:inherit;color:#00F";>Career.Com</span> <small>Company Slogan Here</small></a></h1>
        -->
              </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider">
         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a>
                       
         </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
         <!-- <h2><span>Excellent Solution</span> For Your Business</h2>
          <p class="infopost">Posted on <span class="date">11 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span>11</span></a></p>-->
          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="640" height="188" alt="" class="fl" /></div>
          <div class="post_content">
            <p>      <form action="" method="post" enctype="multipart/form-data">
                    <br>

                    <tr>
                        <td align="center" colspan="2"><p><font size="6" color="#2695C3" face="Times New Roman, Times, serif">&nbsp;&nbsp;
                        Create Your Resume Or Apply Job...</font></p>
                        <p>&nbsp;</p></td>
                    </tr>
                    <table border="2" cellpadding="2" cellspacing="5" width="600" style="margin-left:200;">
                        <tr>
                            <td >Email:</td>
                            <td><input name="email" class="text" id="email" style="width:300px;" type="text" value="<?php echo $r2[1]?>"></td>
                        </tr>

                        <tr>
                            <td>Name:</td>
                            <td width="66%"><input type="text" name="uname" value="<?php echo $r2[2]?>"  id="name" class="text" style="width:300px;"></td>
                        </tr>

                        <tr>
                            <td>Nationality: </td>
                            <td width="66%">
                                <select name="nation" class="txtbox1" id="nation" value="" style="width:300px;">
                                    <option value="<?php echo $r2[3]?>"><?php echo $r2[3]?></option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                    <option value="Antigua And Barbuda">Antigua And Barbuda</option>
                                    <option value="Argentina">Argentina</option>
                                    <option value="Armenia">Armenia</option>
                                    <option value="Aruba">Aruba</option>
                                    <option value="Australia">Australia</option>
                                    <option value="Austria">Austria</option>
                                    <option value="Azerbaijan">Azerbaijan</option>
                                    <option value="Bahamas, The">Bahamas, The</option>
                                    <option value="Bahrain">Bahrain</option>
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="Barbados">Barbados</option>
                                    <option value="Belarus">Belarus</option>
                                    <option value="Belgium">Belgium</option>
                                    <option value="Belize">Belize</option>
                                    <option value="Benin">Benin</option>
                                    <option value="Bermuda">Bermuda</option>
                                    <option value="Bhutan">Bhutan</option>
                                    <option value="Bolivia">Bolivia</option>
                                    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                    <option value="Botswana">Botswana</option>
                                    <option value="Bouvet Island">Bouvet Island</option>
                                    <option value="Brazil">Brazil</option>
                                    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                    <option value="Brunei">Brunei</option>
                                    <option value="Bulgaria">Bulgaria</option>
                                    <option value="Burkina Faso">Burkina Faso</option>
                                    <option value="Burundi">Burundi</option>
                                    <option value="Cambodia">Cambodia</option>
                                    <option value="Cameroon">Cameroon</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Cape Verde">Cape Verde</option>
                                    <option value="Cayman Islands">Cayman Islands</option>
                                    <option value="Central African Republic">Central African Republic</option>
                                    <option value="Chad">Chad</option>
                                    <option value="Chile">Chile</option>
                                    <option value="China">China</option>
                                    <option value="Christmas Island">Christmas Island</option>
                                    <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                    <option value="Colombia">Colombia</option>
                                    <option value="Comoros">Comoros</option>
                                    <option value="Congo">Congo</option>
                                    <option value="Congo, Democractic Republic of the  ">Congo, Democractic Republic of the</option>
                                    <option value="Cook Islands">Cook Islands</option>
                                    <option value="Costa Rica">Costa Rica</option>
                                    <option value="Cote D&#39;Ivoire (Ivory Coast)">Cote D'Ivoire (Ivory Coast)</option>
                                    <option value="Croatia (Hrvatska)">Croatia (Hrvatska)</option>
                                    <option value="Cuba">Cuba</option>
                                    <option value="Cyprus">Cyprus</option>
                                    <option value="Czech Republic">Czech Republic</option>
                                    <option value="Denmark">Denmark</option>
                                    <option value="Djibouti">Djibouti</option>
                                    <option value="Dominica">Dominica</option>
                                    <option value="Dominican Republic">Dominican Republic</option>
                                    <option value="East Timor">East Timor</option>
                                    <option value="Ecuador">Ecuador</option>
                                    <option value="Egypt">Egypt</option>
                                    <option value="El Salvador">El Salvador</option>
                                    <option value="Equatorial Guinea">Equatorial Guinea</option>
                                    <option value="Eritrea">Eritrea</option>
                                    <option value="Estonia">Estonia</option>
                                    <option value="Ethiopia">Ethiopia</option>
                                    <option value="Falkland Islands (Islas Malvinas)">Falkland Islands (Islas Malvinas)</option>
                                    <option value="Faroe Islands">Faroe Islands</option>
                                    <option value="Fiji Islands">Fiji Islands</option>
                                    <option value="Finland">Finland</option>
                                    <option value="France">France</option>
                                    <option value="French Guiana">French Guiana</option>
                                    <option value="French Polynesia">French Polynesia</option>
                                    <option value="French Southern Territories">French Southern Territories</option>
                                    <option value="Gabon">Gabon</option>
                                    <option value="Gambia, The">Gambia, The</option>
                                    <option value="Georgia">Georgia</option>
                                    <option value="Germany">Germany</option>
                                    <option value="Ghana">Ghana</option>
                                    <option value="Gibraltar">Gibraltar</option>
                                    <option value="Greece">Greece</option>
                                    <option value="Greenland">Greenland</option>
                                    <option value="Grenada">Grenada</option>
                                    <option value="Guadeloupe">Guadeloupe</option>
                                    <option value="Guam">Guam</option>
                                    <option value="Guatemala">Guatemala</option>
                                    <option value="Guinea">Guinea</option>
                                    <option value="Guinea-Bissau">Guinea-Bissau</option>
                                    <option value="Guyana">Guyana</option>
                                    <option value="Haiti">Haiti</option>
                                    <option value="Heard and McDonald Islands">Heard and McDonald Islands</option>
                                    <option value="Honduras">Honduras</option>
                                    <option value="Hong Kong S.A.R">Hong Kong S.A.R</option>
                                    <option value="Hungary">Hungary</option>
                                    <option value="Iceland">Iceland</option>
                                    <option value="India">India</option>
                                    <option value="Indonesia">Indonesia</option>
                                    <option value="Iran">Iran</option>
                                    <option value="Iraq">Iraq</option>
                                    <option value="Ireland">Ireland</option>
                                    <option value="Israel">Israel</option>
                                    <option value="Italy">Italy</option>
                                    <option value="Jamaica">Jamaica</option>
                                    <option value="Japan">Japan</option>
                                    <option value="Jordan">Jordan</option>
                                    <option value="Kazakhstan">Kazakhstan</option>
                                    <option value="Kenya">Kenya</option>
                                    <option value="Kiribati">Kiribati</option>
                                    <option value="Korea">Korea</option>
                                    <option value="Korea, North ">Korea, North</option>
                                    <option value="Kuwait">Kuwait</option>
                                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                                    <option value="Laos">Laos</option>
                                    <option value="Latvia">Latvia</option>
                                    <option value="Lebanon">Lebanon</option>
                                    <option value="Lesotho">Lesotho</option>
                                    <option value="Liberia">Liberia</option>
                                    <option value="Libya">Libya</option>
                                    <option value="Liechtenstein">Liechtenstein</option>
                                    <option value="Lithuania">Lithuania</option>
                                    <option value="Luxembourg">Luxembourg</option>
                                    <option value="Macau S.A.R">Macau S.A.R</option>
                                    <option value="Macedonia">Macedonia</option>
                                    <option value="Madagascar">Madagascar</option>
                                    <option value="Malawi">Malawi</option>
                                    <option value="Malaysia">Malaysia</option>
                                    <option value="Maldives">Maldives</option>
                                    <option value="Mali">Mali</option>
                                    <option value="Malta">Malta</option>
                                    <option value="Marshall Islands">Marshall Islands</option>
                                    <option value="Martinique">Martinique</option>
                                    <option value="Mauritania">Mauritania</option>
                                    <option value="Mauritius">Mauritius</option>
                                    <option value="Mayotte">Mayotte</option>
                                    <option value="Mexico">Mexico</option>
                                    <option value="Micronesia">Micronesia</option>
                                    <option value="Moldova">Moldova</option>
                                    <option value="Monaco">Monaco</option>
                                    <option value="Mongolia">Mongolia</option>
                                    <option value="Montserrat">Montserrat</option>
                                    <option value="Morocco">Morocco</option>
                                    <option value="Mozambique">Mozambique</option>
                                    <option value="Myanmar">Myanmar</option>
                                    <option value="Namibia">Namibia</option>
                                    <option value="Nauru">Nauru</option>
                                    <option value="Nepal">Nepal</option>
                                    <option value="Netherlands Antilles">Netherlands Antilles</option>
                                    <option value="Netherlands, The">Netherlands, The</option>
                                    <option value="New Caledonia">New Caledonia</option>
                                    <option value="New Zealand">New Zealand</option>
                                    <option value="Nicaragua">Nicaragua</option>
                                    <option value="Niger">Niger</option>
                                    <option value="Nigeria">Nigeria</option>
                                    <option value="Niue">Niue</option>
                                    <option value="Norfolk Island">Norfolk Island</option>
                                    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                    <option value="Norway">Norway</option>
                                    <option value="Oman">Oman</option>
                                    <option value="Pakistan">Pakistan</option>
                                    <option value="Palau">Palau</option>
                                    <option value="Panama">Panama</option>
                                    <option value="Papua new Guinea">Papua new Guinea</option>
                                    <option value="Paraguay">Paraguay</option>
                                    <option value="Peru">Peru</option>
                                    <option value="Philippines">Philippines</option>
                                    <option value="Pitcairn Island">Pitcairn Island</option>
                                    <option value="Poland">Poland</option>
                                    <option value="Portugal">Portugal</option>
                                    <option value="Puerto Rico">Puerto Rico</option>
                                    <option value="Qatar">Qatar</option>
                                    <option value="Reunion">Reunion</option>
                                    <option value="Romania">Romania</option>
                                    <option value="Russia">Russia</option>
                                    <option value="Rwanda">Rwanda</option>
                                    <option value="Saint Helena">Saint Helena</option>
                                    <option value="Saint Kitts And Nevis">Saint Kitts And Nevis</option>
                                    <option value="Saint Lucia">Saint Lucia</option>
                                    <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                    <option value="Samoa">Samoa</option>
                                    <option value="San Marino">San Marino</option>
                                    <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                    <option value="Saudi Arabia">Saudi Arabia</option>
                                    <option value="Senegal">Senegal</option>
                                    <option value="Seychelles">Seychelles</option>
                                    <option value="Sierra Leone">Sierra Leone</option>
                                    <option value="Singapore">Singapore</option>
                                    <option value="Slovenia">Slovenia</option>
                                    <option value="Solomon Islands">Solomon Islands</option>
                                    <option value="Somalia">Somalia</option>
                                    <option value="South Africa">South Africa</option>
                                    <option value="South Georgia">South Georgia</option>
                                    <option value="Spain">Spain</option>
                                    <option value="Sri Lanka">Sri Lanka</option>
                                    <option value="Sudan">Sudan</option>
                                    <option value="Suriname">Suriname</option>
                                    <option value="Swaziland">Swaziland</option>
                                    <option value="Sweden">Sweden</option>
                                    <option value="Switzerland">Switzerland</option>
                                    <option value="Syria">Syria</option>
                                    <option value="Taiwan">Taiwan</option>
                                    <option value="Tajikistan">Tajikistan</option>
                                    <option value="Tanzania">Tanzania</option>
                                    <option value="Thailand">Thailand</option>
                                    <option value="Togo">Togo</option>
                                    <option value="Tokelau">Tokelau</option>
                                    <option value="Tonga">Tonga</option>
                                    <option value="Trinidad And Tobago">Trinidad And Tobago</option>
                                    <option value="Tunisia">Tunisia</option>
                                    <option value="Turkey">Turkey</option>
                                    <option value="Turkmenistan">Turkmenistan</option>
                                    <option value="Turks And Caicos Islands">Turks And Caicos Islands</option>
                                    <option value="Tuvalu">Tuvalu</option>
                                    <option value="Uganda">Uganda</option>
                                    <option value="Ukraine">Ukraine</option>
                                    <option value="United Arab Emirates">United Arab Emirates</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="United States">United States</option>
                                    <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                    <option value="Uruguay">Uruguay</option>
                                    <option value="Uzbekistan">Uzbekistan</option>
                                    <option value="Vanuatu">Vanuatu</option>
                                    <option value="Vatican City State (Holy See)">Vatican City State (Holy See)</option>
                                    <option value="Venezuela">Venezuela</option>
                                    <option value="Vietnam">Vietnam</option>
                                    <option value="Virgin Islands (British)">Virgin Islands (British)</option>
                                    <option value="Virgin Islands (US)">Virgin Islands (US)</option>
                                    <option value="Wallis And Futuna Islands">Wallis And Futuna Islands</option>
                                    <option value="Yemen">Yemen</option>
                                    <option value="Yugoslavia">Yugoslavia</option>
                                    <option value="Zambia">Zambia</option>
                                    <option value="Zimbabwe">Zimbabwe</option>
                                </select></td>
                        </tr>

                        <tr>
                            <td> Date of Birth: </td>
                            <td><table height="31" border="0" cellpadding="0" cellspacing="0">
                                    <tbody><tr>
                                            <td>
                                                <input type="text" name="date" id="dob"  value="<?php echo $r2[4]?>" style="width:300px;">
                                            </td>
                                        </tr>
                                    </tbody></table></td>
                        </tr>

                        <tr>
                            <td>Gender:</td>
                            <?php
                                if($r2['gender']=="male")
                                {
                                ?>
                                <td><input type="radio" name="gen" id="gen" value="male" checked="checked">Male 
                                    <input type="radio" name="gen" id="gen" value="female">Female 
                                </td>
                                <?php 
                                }
                                else if($r2['gender']=="female")
                                    {
                                    ?>
                                    <td><input type="radio" name="gen" id="gen" value="male">Male 
                                        <input type="radio" name="gen" id="gen" value="female" checked="checked">Female 
                                    </td>
                                    <?php 
                                    }
                                    else
                                    {
                                    ?>
                                    <td><input type="radio" name="gen" id="gen" value="male">Male 
                                        <input type="radio" name="gen" id="gen" value="female">Female 
                                    </td>
                                    <?php 
                                }
                            ?>
                        </tr>
                        <tr class="tabpadding">
                            <td>Current Country  </td>
                            <td width="66%" class="grtxt" align="left">
                                <select name="cbocountry"  id="cbocountry" onChange="Fill_States();" style="width:300px;">

                                    <option value="<?php echo $r2[6]?>"><?php echo $r2[6]?></option>

                                    <option>Afghanistan</option><option>Albania</option><option>Algeria</option><option>American Samoa</option><option>Angola</option><option>Anguilla</option><option>Antartica</option><option>Antigua and Barbuda</option><option>Argentina</option><option>Armenia</option><option>Aruba</option><option>Ashmore and Cartier Island</option><option>Australia</option><option>Austria</option><option>Azerbaijan</option><option>Bahamas</option><option>Bahrain</option><option>Bangladesh</option><option>Barbados</option><option>Belarus</option><option>Belgium</option><option>Belize</option><option>Benin</option><option>Bermuda</option><option>Bhutan</option><option>Bolivia</option><option>Bosnia and Herzegovina</option><option>Botswana</option><option>Brazil</option><option>British Virgin Islands</option><option>Brunei</option><option>Bulgaria</option><option>Burkina Faso</option><option>Burma</option><option>Burundi</option><option>Cambodia</option><option>Cameroon</option><option>Canada</option><option>Cape Verde</option><option>Cayman Islands</option><option>Central African Republic</option><option>Chad</option><option>Chile</option><option>China</option><option>Christmas Island</option><option>Clipperton Island</option><option>Cocos (Keeling) Islands</option><option>Colombia</option><option>Comoros</option><option>Congo, Democratic Republic of the</option><option>Congo, Republic of the</option><option>Cook Islands</option><option>Costa Rica</option><option>Cote d'Ivoire</option><option>Croatia</option><option>Cuba</option><option>Cyprus</option><option>Czeck Republic</option><option>Denmark</option><option>Djibouti</option><option>Dominica</option><option>Dominican Republic</option><option>Ecuador</option><option>Egypt</option><option>El Salvador</option><option>Equatorial Guinea</option><option>Eritrea</option><option>Estonia</option><option>Ethiopia</option><option>Europa Island</option><option>Falkland Islands (Islas Malvinas)</option><option>Faroe Islands</option><option>Fiji</option><option>Finland</option><option>France</option><option>French Guiana</option><option>French Polynesia</option><option>French Southern and Antarctic Lands</option><option>Gabon</option><option>Gambia, The</option><option>Gaza Strip</option><option>Georgia</option><option>Germany</option><option>Ghana</option><option>Gibraltar</option><option>Glorioso Islands</option><option>Greece</option><option>Greenland</option><option>Grenada</option><option>Guadeloupe</option><option>Guam</option><option>Guatemala</option><option>Guernsey</option><option>Guinea</option><option>Guinea-Bissau</option><option>Guyana</option><option>Haiti</option><option>Heard Island and McDonald Islands</option><option>Holy See (Vatican City)</option><option>Honduras</option><option>Hong Kong</option><option>Howland Island</option><option>Hungary</option><option>Iceland</option><option>India</option><option>Indonesia</option><option>Iran</option><option>Iraq</option><option>Ireland</option><option>Ireland, Northern</option><option>Israel</option><option>Italy</option><option>Jamaica</option><option>Jan Mayen</option><option>Japan</option><option>Jarvis Island</option><option>Jersey</option><option>Johnston Atoll</option><option>Jordan</option><option>Juan de Nova Island</option><option>Kazakhstan</option><option>Kenya</option><option>Kiribati</option><option>Korea, North</option><option>Korea, South</option><option>Kuwait</option><option>Kyrgyzstan</option><option>Laos</option><option>Latvia</option><option>Lebanon</option><option>Lesotho</option><option>Liberia</option><option>Libya</option><option>Liechtenstein</option><option>Lithuania</option><option>Luxembourg</option><option>Macau</option><option>Macedonia, Former Yugoslav Republic of</option><option>Madagascar</option><option>Malawi</option><option>Malaysia</option><option>Maldives</option><option>Mali</option><option>Malta</option><option>Man, Isle of</option><option>Marshall Islands</option><option>Martinique</option><option>Mauritania</option><option>Mauritius</option><option>Mayotte</option><option>Mexico</option><option>Micronesia, Federated States of</option><option>Midway Islands</option><option>Moldova</option><option>Monaco</option><option>Mongolia</option><option>Montserrat</option><option>Morocco</option><option>Mozambique</option><option>Namibia</option><option>Nauru</option><option>Nepal</option><option>Netherlands</option><option>Netherlands Antilles</option><option>New Caledonia</option><option>New Zealand</option><option>Nicaragua</option><option>Niger</option><option>Nigeria</option><option>Niue</option><option>Norfolk Island</option><option>Northern Mariana Islands</option><option>Norway</option><option>Oman</option><option>Pakistan</option><option>Palau</option><option>Panama</option><option>Papua New Guinea</option><option>Paraguay</option><option>Peru</option><option>Philippines</option><option>Pitcaim Islands</option><option>Poland</option><option>Portugal</option><option>Puerto Rico</option><option>Qatar</option><option>Reunion</option><option>Romainia</option><option>Russia</option><option>Rwanda</option><option>Saint Helena</option><option>Saint Kitts and Nevis</option><option>Saint Lucia</option><option>Saint Pierre and Miquelon</option><option>Saint Vincent and the Grenadines</option><option>Samoa</option><option>San Marino</option><option>Sao Tome and Principe</option><option>Saudi Arabia</option><option>Scotland</option><option>Senegal</option><option>Seychelles</option><option>Sierra Leone</option><option>Singapore</option><option>Slovakia</option><option>Slovenia</option><option>Solomon Islands</option><option>Somalia</option><option>South Africa</option><option>South Georgia and South Sandwich Islands</option><option>Spain</option><option>Spratly Islands</option><option>Sri Lanka</option><option>Sudan</option><option>Suriname</option><option>Svalbard</option><option>Swaziland</option><option>Sweden</option><option>Switzerland</option><option>Syria</option><option>Taiwan</option><option>Tajikistan</option><option>Tanzania</option><option>Thailand</option><option>Tobago</option><option>Toga</option><option>Tokelau</option><option>Tonga</option><option>Trinidad</option><option>Tunisia</option><option>Turkey</option><option>Turkmenistan</option><option>Tuvalu</option><option>Uganda</option><option>Worldraine</option><option>United Arab Emirates</option><option>United Kingdom</option><option>Uruguay</option><option>USA</option><option>Uzbekistan</option><option>Vanuatu</option><option>Venezuela</option><option>Vietnam</option><option>Virgin Islands</option><option>Wales</option><option>Wallis and Futuna</option><option>West Bank</option><option>Western Sahara</option><option>Yemen</option><option>Zambia</option><option>Zimbabwe</option></select></td>
                        </tr>



                        <tr>
                            <td> Current City:</td>
                            <td align="left"><input name="city" value="<?php echo $r2[7]?>" type="text" id="city" size="40" style="width:300px;"></td>
                        </tr>
                        <tr>
                            <td> Contact Number: </td>
                            <td width="66%" align="left"><table width="70%" border="0" cellspacing="2" cellpadding="0">
                                    <tbody> 

                                        <tr>
                                            <td  colspan="3">
                                                <input name="mobile" value="<?php echo $r2[8]?>" type="text" id="mobile" style="width:200px;" size="10" maxlength="15"></td>
                                        </tr>
                                    </tbody></table></td>
                        </tr>
                        </tbody> 


                        <tbody><tr>
                                <td>Bachelor Degree:</td>
                                <td width="67%" align="left">
                                    <select name="degree" id="degree" style="width:300px;" onChange="occu1()">
                                        <option  value="<?php echo $r2[9]?>"><?php echo $r2[9]?></option>



                                        <option value="Bca">Bca</option>      




                                        <option value="B.Com">B.Com</option>
                                        <option value="B.Sc">B.Sc</option>
                                        <option value="BBA">BBA</option>
                                        <option value="ITI">ITI</option>
                                        <option value="P.G Diploma">P.G Diploma</option>
                                        <option value="Diploma">Diploma</option>
                                        <option value="BA">BA</option>   
                                        <option value="B.E">B.E</option>
                                        <option value="B.Tech">B.Tech</option>


                                        <option value="Others">Others</option>
                                    </select>
                                    &nbsp;</td>
                            </tr>

                            <tr>
                                <td>Bachelor Institution:</td>
                                <td width="67%" align="left">
                                <input type="text" name="institute" value="<?php echo $r2[10]?>"id="institute" style="width:300px;">                                        </td>
                            </tr>

                            <tr>
                                <td>Master Degree:</td>
                                <td width="67%" align="left">
                                    <select name="mdegree"  id="mdegree" style="width:300px;" onChange="occu1()">
                                        <option selected="selected" value="<?php echo $r2[11]?>"><?php echo $r2[11]?></option>


                                        <option value="M.com">M.com</option>

                                        <option value=" M.Sc (Computer Science)">M.Sc (Computer Science)</option>
                                        <option value="MA">MA</option>
                                        <option value="MBBS">MBBS</option>
                                        <option value="P.G Diploma">P.G Diploma</option>
                                        <option value="Diploma">Diploma</option>
                                        <option value="MCA">MCA</option>
                                        <option value="MSc">MSc</option>
                                        <option value="M.Tech">M.Tech</option>
                                        <option value="Others">Others</option>
                                    </select>
                                    &nbsp;</td>
                            </tr>

                            <tr>
                                <td>Master Institution:</td>
                                <td width="67%" align="left">
                                <input type="text" name="minstitute" value="<?php echo $r2[12]?>" id="minstitute" style="width:300px;">                                        </td>
                            </tr>


                            <tr>


                                <td> Year of Graduation: </td>
                                <td width="67%" align="left"><select id="gradyear" name="gradyear" style="width:300px;">
                                        <option value="<?php echo $r2[13]?>" selected="selected"><?php echo $r2[13]?></option>
  <option value="2009">2015</option>
                                      
 <option value="2009">2014</option>
                                       <option value="2009">2013</option>
                                        <option value="2009">2012</option>
                                        <option value="2009">2011</option>
                                        <option value="2009">2010</option>
                                        <option value="2009">2009</option>
                                        <option value="2008">2008</option>
                                        <option value="2007">2007</option>

                                        <option value="2006">2006</option>
                                        <option value="2005">2005</option>
                                        <option value="2004">2004</option>
                                        <option value="2003">2003</option>
                                        <option value="2002">2002</option>
                                        <option value="2001">2001</option>

                                        <option value="2000">2000</option>
                                        <option value="1999">1999</option>
                                        <option value="1998">1998</option>
                                        <option value="1997">1997</option>
                                        <option value="1996">1996</option>
                                        <option value="1995">1995</option>

                                        <option value="1994">1994</option>
                                        <option value="1993">1993</option>
                                        <option value="1992">1992</option>
                                        <option value="1991">1991</option>
                                        <option value="1990">1990</option>
                                        <option value="1989">1989</option>

                                        <option value="1988">1988</option>
                                        <option value="1987">1987</option>
                                        <option value="1986">1986</option>
                                        <option value="1985">1985</option>
                                        <option value="1984">1984</option>
                                        <option value="1983">1983</option>

                                        <option value="1982">1982</option>
                                        <option value="1981">1981</option>
                                        <option value="1980">1980</option>
                                        <option value="1979">1979</option>
                                        <option value="1978">1978</option>
                                        <option value="1977">1977</option>

                                        <option value="1976">1976</option>
                                        <option value="1975">1975</option>
                                        <option value="1974">1974</option>
                                        <option value="1973">1973</option>
                                        <option value="1972">1972</option>
                                        <option value="1971">1971</option>

                                        <option value="1970">1970</option>
                                        <option value="1969">1969</option>
                                        <option value="1968">1968</option>
                                        <option value="1967">1967</option>
                                        <option value="1966">1966</option>
                                        <option value="1965">1965</option>

                                        <option value="1964">1964</option>
                                        <option value="1963">1963</option>
                                        <option value="1962">1962</option>
                                        <option value="1961">1961</option>
                                        <option value="1960">1960</option>
                                        <option value="1959">1959</option>

                                        <option value="1958">1958</option>
                                        <option value="1957">1957</option>
                                        <option value="1956">1956</option>
                                        <option value="1955">1955</option>
                                        <option value="1954">1954</option>
                                        <option value="1953">1953</option>

                                        <option value="1952">1952</option>
                                        <option value="1951">1951</option>
                                        <option value="1950">1950</option>
                                        <option value="1949">1949</option>
                                        <option value="1948">1948</option>
                                        <option value="1947">1947</option>

                                        <option value="1946">1946</option>
                                        <option value="1945">1945</option>
                                        <option value="1944">1944</option>
                                        <option value="1943">1943</option>
                                        <option value="1942">1942</option>
                                        <option value="1941">1941</option>

                                        <option value="1940">1940</option>
                                    </select></td>
                            </tr>
                        </tbody> 


                        <tbody><tr>
                            <td>Total Experience: </td>
                            <td> 

                                <select name="month" id="month">

                                    <option value="" selected="selected">Month</option>
                                    <?php
                                        for($i=1;$i<=12;$i++)
                                        {
                                            if($i==$row['month'])
                                            {
                                            ?>
                                            <option value="<?php echo $i ?>" selected="selected"><?php echo $i ?></option>                                                            
                                            <?php        
                                            }
                                            else
                                            {
                                            ?>
                                            <option value="<?php echo $i ?>"><?php echo $i ?></option>                                                            
                                            <?php
                                            }

                                        }
                                    ?>  

                                </select>

                                <select name="year" id="year">
                                    <option value="" selected="selected">Year</option>
                                    <?php
                                        for($i=1;$i<=15;$i++)
                                        {
                                            if($i==$row['year'])
                                            {
                                            ?>
                                            <option value="<?php echo $i ?>" selected="selected"><?php echo $i ?></option>
                                            <?php 
                                            }
                                            else
                                            {
                                            ?>
                                            <option value="<?php echo $i ?>"><?php echo $i ?> </option>
                                            <?php
                                            }

                                        }
                                    ?>  
                                </select>
                            </td>
                        </tr> 
                        <tr>
                            <td>Annual Salary: </td>
                            <td width="66%" align="left">
                                <select name="as" value="<?php echo $r2[15]?>"  value="as" title="Required" validate="required:true">
                                    <option value="Currency" selected="selected">Currency </option>
                                    <option value="US Dollars">US Dollars</option>
                                    <option value="Euros">Euros</option>
                                    <option value="Sterling Pound">Sterling Pound</option>
                                    <option value="Dirhams">Dirhams</option>
                                    <option value="AUD">AUD</option>
                                    <option value="Rs">Rs</option>
                                </select>
                                <input type="text" name="as"value="<?php echo $r2[15]?>" id="as" maxlength="20" style="width:100px;">        


                                <select name="as" value="<?php echo $r2[15]?>"title="Required" value="as" id="" validate="required:true">
                                <option value="" selected="selected">Period</option>
                                <option value="Yearly">Yearly</option>
                                <option value="Monthly">Monthly</option>
                                <option value="Weekly">Weekly</option>
                                <option value="Daily">Daily</option>
                                <option value="Hourly">Hourly</option>
                            </select>                                    </td>
                        </tr>
                        <tr>
                            <td>Industry:</td>
                            <td width="66%" align="left">
                                <select name="industry" value="ind" id="ind" style="width:300px;">
                                    <option value="<?php echo $r2[16]?>"><?php echo $r2[16]?></option>
                                    <option value="Aeronautical Engineering,  Design">Aeronautical Engineering,  Design</option>
                                    <option value="Agriculture">Agriculture</option>
                                    <option value="Airport Management,  Airline Crew">Airport Management,  Airline Crew</option>
                                    <option value="Architecture,  Interior Design">Architecture,  Interior Design</option>
                                    <option value="Automobile,  Manufacturing">Automobile,  Manufacturing</option>
                                    <option value="Biotechnology">Biotechnology</option>
                                    <option value="Civil,  Infrastructure,  Constructionw">Civil,  Infrastructure,  Constructionw</option>
                                    <option value="Consulting, Services">Consulting, Services</option>
                                    <option value="demo">demo</option>
                                    <option value="Education, Teaching">Education, Teaching</option>
                                    <option value="Engineering and gas">Engineering and gas</option>
                                    <option value="Engineering Services,  Consulting">Engineering Services,  Consulting</option>
                                    <option value="entah">entah</option>
                                    <option value="Environmental">Environmental</option>
                                    <option value="Event Management">Event Management</option>
                                    <option value="FMCG">FMCG</option>
                                    <option value="Food &amp; Beverages">Food &amp; Beverages</option>
                                    <option value="Grant Thornton">Grant Thornton</option>
                                    <option value="hardik">hardik</option>
                                    <option value="hghg">hghg</option>
                                    <option value="Higher Secondary (Class 8th to Class 10th)">Higher Secondary (Class 8th to Class 10th)</option>
                                    <option value="Hotel Management &amp; Catering">Hotel Management &amp; Catering</option>
                                    <option value="Industrial Manufacturing,  Production">Industrial Manufacturing,  Production</option>
                                    <option value="Information Technology">Information Technology</option>
                                    <option value="IT, KPO, BPO,cposdfsdfiho,kkkk">IT, KPO, BPO,cposdfsdfiho,kkkk</option>
                                    <option value="Logistics,  Distribution ">Logistics,  Distribution </option>
                                    <option value="Management,  Consulting">Management,  Consulting</option>
                                    <option value="marketing">marketing</option>
                                    <option value="Marketing,  Sales">Marketing,  Sales</option>
                                    <option value="Mechanical Engineering">Mechanical Engineering</option>
                                    <option value="Media &amp; Entertainment">Media &amp; Entertainment</option>
                                    <option value="Oil &amp; Gas">Oil &amp; Gas</option>
                                    <option value="Online Marketing">Online Marketing</option>
                                    <option value="Pharmaceuticals">Pharmaceuticals</option>
                                    <option value="Power, Electrical">Power, Electrical</option>
                                    <option value="Primary Teacher (Nur - Class 5th)">Primary Teacher (Nur - Class 5th)</option>
                                    <option value="resume">resume</option>
                                    <option value="retail">retail</option>
                                    <option value="Retail, Super Markets">Retail, Super Markets</option>
                                    <option value="rev">rev</option>
                                    <option value="Roads &amp; Highways">Roads &amp; Highways</option>
                                    <option value="Safety Engineering">Safety Engineering</option>
                                    <option value="sdas">sdas</option>
                                    <option value="Secondary Teacher (Class 5th to Class 8th)">Secondary Teacher (Class 5th to Class 8th)</option>
                                    <option value="Senior Secondary (Class 10th to Class 12th)">Senior Secondary (Class 10th to Class 12th)</option>
                                    <option value="Telecommunications">Telecommunications</option>
                                    <option value="testing guide">testing guide</option>
                            </select>  </td>
                        </tr>
                        <tr>
                            <td >Functional Area:</td>
                            <td>
                                <select name="funcarea"  id="funcarea" size="1" onChange="area(this.value,document.formn.func.value)" style="width:300px;">
                                    <option selected="selected" value="<?php echo $r2[17]?>"><?php echo $r2[17]?></option>
                                    <option value="Freshers/Trainee">Freshers/Trainee</option>
                                    <option value="Accounting/Auditing/Tax/Financial Services">Accounting/Auditing/Tax/Financial Services</option>
                                    <option value="Admin/office support/secretary/Data Entry">Admin/office support/secretary/Data Entry</option>
                                    <option value="Advertising/Event Management/Media/PR">Advertising/Event Management/Media/PR</option>
                                    <option value="Agriculture/Fishing/Forestry/Horticulture">Agriculture/Fishing/Forestry/Horticulture</option>
                                    <option value="Airlines/Travel/Ticketing">Airlines/Travel/Ticketing</option>
                                    <option value="Architecture/Construction/Interior/PropertyMgmt">Architecture/Construction/Interior/PropertyMgmt</option>
                                    <option value="Banking/Insurance">Banking/Insurance</option>
                                    <option value="Beauty/Personal Care/Fitness/SPA">Beauty/Personal Care/Fitness/SPA</option>
                                    <option value="Biotech/Research">Biotech/Research</option>
                                    <option value="BPO/ITES/KPO/Customer Service/Technical Support">BPO/ITES/KPO/Customer Service/Technical Support</option>
                                    <option value="Business Strategy/Management/Consulting">Business Strategy/Management/Consulting</option>
                                    <option value="Engineering">Engineering</option>
                                    <option value="Engineering Design/Production">Engineering Design/Production</option>
                                    <option value="Fashion Designing/Modeling/Jewellery">Fashion Designing/Modeling/Jewellery</option>
                                    <option value="Health Care/ Medicine/Nursing">Health Care/ Medicine/Nursing</option>
                                    <option value="Hotel Management/Catering/Food Technology">Hotel Management/Catering/Food Technology</option>
                                    <option value="Human Resources">Human Resources</option>
                                    <option value="Import/Export">Import/Export</option>
                                    <option value="IT - Hardware">IT - Hardware</option>
                                    <option value="IT - Networking">IT - Networking</option>
                                    <option value="IT- Software">IT- Software</option>
                                    <option value="Legal/Law">Legal/Law</option>
                                    <option value="Marketing &amp; Product Management/Tele Marketing">Marketing &amp; Product Management/Tele Marketing</option>
                                    <option value="Operations">Operations</option>
                                    <option value="Packaging /Delivery/ Logistics Operations">Packaging /Delivery/ Logistics Operations</option>
                                    <option value="Pharmaceuticals">Pharmaceuticals</option>
                                    <option value="Photography/TV / films / Radio">Photography/TV / films / Radio</option>
                                    <option value="Quality Control">Quality Control</option>
                                    <option value="Retail/Counter/Merchandising/Procurement">Retail/Counter/Merchandising/Procurement</option>
                                    <option value="Sales/Business Development">Sales/Business Development</option>
                                    <option value="Security/National Defence Personnel">Security/National Defence Personnel</option>
                                    <option value="Shipping/Merchant Navy">Shipping/Merchant Navy</option>
                                    <option value="Skilled Labour/Technician">Skilled Labour/Technician</option>
                                    <option value="Social Service/NGO">Social Service/NGO</option>
                                    <option value="Supply chain Mgmt/Distribution/Inventory Mgmt">Supply chain Mgmt/Distribution/Inventory Mgmt</option>
                                    <option value="Teaching/Training">Teaching/Training</option>
                                    <option value="Top Management/Senior Management">Top Management/Senior Management</option>
                                    <option value="Graphic Designer/Visualizer">Graphic Designer/Visualizer</option>
                                    <option value="Editorial/Content/Journalism">Editorial/Content/Journalism</option>
                                    <option value="Others">Others</option>
                                </select>
                            </td>
                        </tr>


                        
                        <tr>
                            <td> Upload resume: </td>
                            <td><input name="file[]" value="<?php echo $r2[19]?>" id="file" type="file" class="multi"  multiple="multiple" accept="application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" validate="required:true" style="width:300px;">
                                <br>
                                <span class="grey-11">Please make sure your document is closed before uploading it to avoid any errors.
                                    - You may upload Word / Acrobat / Text (<strong>.doc / .pdf / .txt</strong>) documents.
                                    - Maximum size 125kb</span></td> 
                        </tr>     
                        <tr>
 <input type="file" id="resume" style="visibility: hidden" name="file">
                        </tr>

                        <tr>                                     </tr>
                        <?php
                            if($_REQUEST['rid'])
                            {
                            ?>
                            <td>
                            </td>
                            <td>
                                &nbsp;&nbsp;&nbsp; <input type="submit" name="update" value="UPDATE" onClick="return mesg(this.form);"/>
                                &nbsp;&nbsp;&nbsp;&nbsp; <input type="reset" name="RESET" value="RESET" /></td>  
                            <?php 
                            }
                            else
                            {
                            ?>
                            <td > </td>
                            <td> 
                                &nbsp;&nbsp;&nbsp;  <input type="submit" name="submit" value="SUBMIT" onClick="return mesg(this.form);"/>
                                &nbsp;&nbsp;&nbsp;&nbsp; <input type="reset" name="RESET" value="RESET" /></td>  
                            <?php 
                            }
                        ?>
                        </tr>
                    </table>

                </form>
 </p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="">
          
         
          <div class="post_content">
             
          </div>
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
             <?php
    if($_SESSION['uname'])
    {
        ?>
         <li><a href="Home.php">Main Page</a></li>
                    <li><a href="jobseeker_home.php?uname=<?php echo $uname?>">Account Detail</a></li>
                    <li><a href="jseeker_pass_change.php ?uname=<?php echo $uname?>">Change Password </a></li>
                    <!--<li><a href="Post Resume.php">Resume</a></li>-->
                    <li><a href="eresume.php ?uname=<?php echo $uname?>">view Resume</a></li>
                    <!--<li><a href="search job1.php">Job Search</a></li>-->
                    <li><a href="feed back1.php ?uname=<?php echo $uname?>">Feed Back </a></li>
                    <li><a href="Contect.php ?uname=<?php echo $uname?>">Contact Us</a></li>
                    <!--<li><a href="msg.php?uname=<?php echo $uname?>">Inbox</a></li>
-->                    <li class="last"><a href="logout.php">Logout</a></li>
        <?php 
    }
    else
    {
        ?>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="employee.php"><span>Employer</span></a></li>
          <li><a href="jobseeker.php"><span>Jobseeker</span></a></li>
          <li><a href="About.php"><span>About</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        <?php 
    }
?>
          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
           
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
     
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by Krupa & Khushbu<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>
