<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<div align="center">

<div class="slider">
        <div id="coin-slider"> 
         <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> 
        </a>
                       
         </div>
      </div>
      </div>
<body>
</body>
</html>