
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lan="guj">
<head>
<title>About</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-titillium-600.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main subpage">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
           <li class="active"><a href="index.php"><span>પ્રથમપાનું</span></a></li>
         <!-- <li><a href="employee.php"><span>Employee</span></a></li>-->
          <li><a href="jobseeker.php"><span>રોજગાર શોધક</span></a></li>
          <li><a href="About.php"><span>વિશેષ માહિતી</span></a></li>
          <li><a href="contact.php"><span>સંપર્ક</span></a></li>
        </ul>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <!--<span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
-->        </form>
      </div>
      <div class="clr"></div>
      <div class="logo">
      <h1><a href="index.html"><img src="images/logo2.png" width="135" height="75" /><small></small></a></h1>

       <!-- <h1 style="font-size:40px;color:#00C;"><a href="index.html"><span style="font-style:inherit;color:#00F";>Career.Com</span> <small>Company Slogan Here</small></a></h1>
     --> </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/company-and-business-setup-services.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-models.jpg" width="918" height="310" alt="" /> </a> 
        <a href="#"><img src="images/business-meeting-venue-for-.jpg" width="918" height="310" alt="" /> </a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
         <!-- <h2><span>About to</span> Company Name</h2>
-->          <div class="clr"></div>
    <!--      <p><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum eget bibendum tellus. Nunc vel imperdiet tellus. Mauris ornare aliquam urna, accumsan bibendum eros auctor ac.</strong></p>
          <p>Curabitur purus mi, pharetra vitae viverra et, mattis sit amet nunc. Quisque enim ipsum, convallis sit amet molestie in, placerat vel urna. Praesent congue auctor elit, nec pretium ipsum volutpat vitae. Vivamus eget ipsum sit amet ipsum tincidunt fermentum. Sed hendrerit neque ac erat condimentum vulputate. Nulla velit massa, dictum etinterdum quis, tempus at velit.</p>
-->        </div>
        <div class="article">
          <!--<h2><span>Our</span> Mission</h2>-->
          <div class="clr">
          
                   
            <p>&nbsp;</p>
            </p>
            <p>&nbsp;</p>
          </div>
           <div class="article">
                <h2><span><a href="#">માહિતી</a></span></h2>
            </div>   
          <p>  નોકરી ઓફ ગુજરાત મા આપ નુ સ્વાગત છે.આ વેબસાઇટ તેના લાયકાત મુજબ વિવિધ નોકરી શોધવા માટે જોબ શોધ કરવાની સુવિધા પૂરી પાડે છે.આ વેબસાઇટ પોતે રજીસ્ટર અને તેમના શૈક્ષણિક માહિતી સાથે તમે પ્રોફાઇલ બનાવી શકો છો તેમજ નોકરી શોધવા અને નોકરી માટે અરજી કરી શકો છો.
</p>
      <p>
     આ વેબસાઈટ પણ વિવિધ નોકરીદાતા જેઓ તેમની સંસ્થામાં માં કર્મચારીઓની ભરતી કરવા માટે જરૂરી માટે બનાવાયેલ છે. આ વેબસાઈટ પર પોતે રજીસ્ટર અને તેમણે તેમના સંસ્થા વિવિધ કામ ખાલી જગ્યાઓ ની માહિતી અપલોડ કરી શકે છે. તેમજ નિયોક્તા નોકરી ના કાર્યક્રમો જોવા અને નોકરી ઓફ ગુજરાત્ માટે સૂચના પત્ર મોકલી શકો છો.

</p>

         
        </div>
      </div>
      <div class="sidebar">
        <div class="gadget">
        સાઇડબાર મેનુ
          <h2 class="star"><span></span></h2>
         
           
            <div class="clr"></div>
           <ul class="sb_menu">
          <li class="active"><a href="index.php"><span>પ્રથમપાનું</span></a></li>
         
          <li><a href="About.php"><span>માહિતી</span></a></li>
          <li><a href="contact.php"><span>સંપર્ક</span></a></li>
        </ul>

        </div>
        <div class="gadget">
          <div class="clr"></div>
         
        </div>
      </div>
      <div class="clr">
          </div>
    </div>
  </div>
  <div class="fbg">
   
      <div class="clr"></div>
    </div>
  </div>
   <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Job Portal</a>.</p>
      <p class="rf">Design by ફરહાન,જયસિંગ,કૃપા,જીગીતા,મયુરી<a href=""></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div>
</body>
</html>
